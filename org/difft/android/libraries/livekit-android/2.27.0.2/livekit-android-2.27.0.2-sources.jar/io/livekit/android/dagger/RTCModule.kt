/*
 * Copyright 2023-2026 LiveKit, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package io.livekit.android.dagger

import android.content.Context
import android.javax.sdp.SdpFactory
import android.media.AudioAttributes
import android.media.MediaRecorder
import android.os.Build
import dagger.Module
import dagger.Provides
import dagger.Reusable
import io.livekit.android.LiveKit
import io.livekit.android.audio.AudioBufferCallbackDispatcher
import io.livekit.android.audio.AudioProcessingController
import io.livekit.android.audio.AudioProcessorOptions
import io.livekit.android.audio.AudioRecordPrewarmer
import io.livekit.android.audio.AudioRecordSamplesDispatcher
import io.livekit.android.audio.CommunicationWorkaround
import io.livekit.android.audio.JavaAudioRecordPrewarmer
import io.livekit.android.audio.NoAudioRecordPrewarmer
import io.livekit.android.e2ee.DataPacketCryptorManager
import io.livekit.android.e2ee.DataPacketCryptorManagerImpl
import io.livekit.android.memory.CloseableManager
import io.livekit.android.room.transport.QuicTransport
import io.livekit.android.room.transport.QuicWithFallbackTransport
import io.livekit.android.room.transport.SignalTransport
import io.livekit.android.room.transport.WebSocketTransport
import io.livekit.android.util.LKLog
import io.livekit.android.util.LoggingLevel
import io.livekit.android.webrtc.CustomAudioProcessingFactory
import io.livekit.android.webrtc.CustomVideoDecoderFactory
import io.livekit.android.webrtc.CustomVideoEncoderFactory
import io.livekit.android.webrtc.PeerConnectionFactoryManager
import io.livekit.android.webrtc.peerconnection.RTCThreadToken
import io.livekit.android.webrtc.peerconnection.RTCThreadTokenImpl
import io.livekit.android.webrtc.peerconnection.executeBlockingOnRTCThread
import io.livekit.android.webrtc.peerconnection.executeOnRTCThread
import livekit.org.webrtc.AudioProcessingFactory
import livekit.org.webrtc.EglBase
import livekit.org.webrtc.Logging
import livekit.org.webrtc.MediaStreamTrack
import livekit.org.webrtc.PeerConnectionFactory
import livekit.org.webrtc.RtpCapabilities
import livekit.org.webrtc.SoftwareVideoDecoderFactory
import livekit.org.webrtc.SoftwareVideoEncoderFactory
import livekit.org.webrtc.VideoDecoderFactory
import livekit.org.webrtc.VideoEncoderFactory
import livekit.org.webrtc.audio.AudioDeviceModule
import livekit.org.webrtc.audio.JavaAudioDeviceModule
import okhttp3.OkHttpClient
import org.difft.android.smp.Config
import org.difft.android.smp.Connector
import org.difft.android.smp.Const
import javax.inject.Named
import javax.inject.Singleton

/**
 * @suppress
 */
typealias CapabilitiesGetter = @JvmSuppressWildcards (MediaStreamTrack.MediaType) -> RtpCapabilities

/**
 * @suppress
 */
@Module
internal object RTCModule {

    private fun stripQuicLogPrefix(message: String): String {
        val prefixEnd = findQuicTimestampPrefixEnd(message) ?: findQuicBracketPairPrefixEnd(message)
        val stripped = prefixEnd?.let { message.substring(it) }
        return if (!stripped.isNullOrEmpty()) stripped else message
    }

    private fun findQuicTimestampPrefixEnd(message: String): Int? {
        var index = 0
        while (index < message.length && message[index] in '0'..'9') {
            index++
        }
        index = skipQuicLogPrefixWhitespace(message, index)

        if (index >= message.length || message[index] != '[') {
            return null
        }

        val firstClose = message.indexOf(']', startIndex = index + 1)
        if (firstClose == -1) {
            return null
        }
        if (isQuicLogTimestamp(message, index + 1)) {
            return skipQuicLogPrefixWhitespace(message, firstClose + 1)
        }

        val secondOpen = skipQuicLogPrefixWhitespace(message, firstClose + 1)
        if (secondOpen >= message.length || message[secondOpen] != '[') {
            return null
        }
        if (!isQuicLogTimestamp(message, secondOpen + 1)) {
            return null
        }

        val secondClose = message.indexOf(']', startIndex = secondOpen + 1)
        return if (secondClose != -1) skipQuicLogPrefixWhitespace(message, secondClose + 1) else null
    }

    private fun findQuicBracketPairPrefixEnd(message: String): Int? {
        val firstClose = message.indexOf(']')
        if (firstClose == -1) {
            return null
        }

        val secondOpen = skipQuicLogPrefixWhitespace(message, firstClose + 1)
        if (secondOpen >= message.length || message[secondOpen] != '[') {
            return null
        }

        val secondClose = message.indexOf(']', startIndex = secondOpen + 1)
        return if (secondClose != -1) skipQuicLogPrefixWhitespace(message, secondClose + 1) else null
    }

    private fun isQuicLogTimestamp(message: String, start: Int): Boolean {
        return start + 10 <= message.length &&
            message[start] in '0'..'9' &&
            message[start + 1] in '0'..'9' &&
            message[start + 2] in '0'..'9' &&
            message[start + 3] in '0'..'9' &&
            (message[start + 4] == '/' || message[start + 4] == '-') &&
            message[start + 5] in '0'..'9' &&
            message[start + 6] in '0'..'9' &&
            (message[start + 7] == '/' || message[start + 7] == '-') &&
            message[start + 8] in '0'..'9' &&
            message[start + 9] in '0'..'9'
    }

    private fun skipQuicLogPrefixWhitespace(message: String, start: Int): Int {
        var index = start
        while (index < message.length && message[index] <= ' ') {
            index++
        }
        return index
    }

    /**
     * To only be written to on the WebRTC thread.
     */
    private var hasInitializedWebrtc = false

    /**
     * Certain classes require libwebrtc to be initialized prior to use.
     *
     * If your provision depends on libwebrtc initialization, just add it
     * as a dependency in your method signature.
     *
     * Example:
     *
     * ```
     * @Provides
     * fun someFactory(
     *     @Suppress("UNUSED_PARAMETER")
     *     @Named(InjectionNames.LIB_WEBRTC_INITIALIZATION)
     *     webrtcInitialization: LibWebrtcInitialization
     * ): SomeFactory {
     *     ...
     * }
     * ```
     */
    @Provides
    @Singleton
    @Named(InjectionNames.LIB_WEBRTC_INITIALIZATION)
    fun libWebrtcInitialization(appContext: Context): LibWebrtcInitialization {
        if (!hasInitializedWebrtc) {
            executeBlockingOnRTCThread(LibWebrtcInitializationThreadToken) {
                if (!hasInitializedWebrtc) {
                    hasInitializedWebrtc = true
                    PeerConnectionFactory.initialize(
                        PeerConnectionFactory.InitializationOptions
                            .builder(appContext)
                            .setNativeLibraryName("lkjingle_peerconnection_so")
                            .setFieldTrials(
                                "WebRTC-Audio-Engine-DefaultEnabledAEC/Enabled/" +
                                    "WebRTC-Audio-Engine-DefaultEnabledAGC/Enabled/" +
                                    "WebRTC-Audio-Engine-DefaultEnabledNS/Enabled/" +
                                    "WebRTC-Audio-Engine-DefaultEnabledHPF/Enabled/" +
                                    "WebRTC-Audio-Engine-Android-AecMobile/Disabled/",
                            )
                            .setInjectableLogger(
                                { s, severity, s2 ->
                                    if (!LiveKit.enableWebRTCLogging) {
                                        return@setInjectableLogger
                                    }

                                    val loggingLevel = severity.toLiveKitLogLevel()

                                    LKLog.log(loggingLevel, null) { "[webrtc] $s2: $s".trimEnd('\r', '\n') }
                                },
                                LiveKit.loggingLevelWebRTC.toWebrtcLogLevel(),
                            )
                            .createInitializationOptions(),
                    )
                }
            }
        }
        return LibWebrtcInitialization
    }

    private fun Logging.Severity.toLiveKitLogLevel(): LoggingLevel = when (this) {
        Logging.Severity.LS_VERBOSE -> LoggingLevel.VERBOSE
        Logging.Severity.LS_INFO -> LoggingLevel.INFO
        Logging.Severity.LS_WARNING -> LoggingLevel.WARN
        Logging.Severity.LS_ERROR -> LoggingLevel.ERROR
        else -> LoggingLevel.OFF
    }

    private fun fromQuicLogLevel(level: Int): LoggingLevel = when (level) {
        Const.LOG_DEBUG -> LoggingLevel.DEBUG
        Const.LOG_INFO -> LoggingLevel.INFO
        Const.LOG_WARN -> LoggingLevel.WARN
        Const.LOG_ERROR, Const.LOG_FATAL -> LoggingLevel.ERROR
        else -> LoggingLevel.INFO
    }

    private fun LoggingLevel.toWebrtcLogLevel(): Logging.Severity = when (this) {
        LoggingLevel.VERBOSE -> Logging.Severity.LS_VERBOSE
        LoggingLevel.DEBUG, LoggingLevel.INFO -> Logging.Severity.LS_INFO
        LoggingLevel.WARN -> Logging.Severity.LS_WARNING
        LoggingLevel.ERROR, LoggingLevel.WTF -> Logging.Severity.LS_ERROR
        else -> Logging.Severity.LS_NONE
    }

    private fun LoggingLevel.toQuicLogLevel(): Int = when (this) {
        LoggingLevel.VERBOSE, LoggingLevel.DEBUG -> Const.LOG_DEBUG
        LoggingLevel.INFO -> Const.LOG_INFO
        LoggingLevel.WARN -> Const.LOG_WARN
        LoggingLevel.ERROR -> Const.LOG_ERROR
        LoggingLevel.WTF -> Const.LOG_FATAL
        else -> Const.LOG_INFO
    }

    @Provides
    @Singleton
    fun ttsignalConnector(): Connector {
        val config = Config()
        config.taskThreads = 1
        config.timerThreads = 1
        config.idleTimeOut = 20000
        config.alpn = "ttsignal"
        config.hostname = "localhost"
        config.port = 443
        config.maxConnections = 1000
        config.congestCtrl = Const.CC_BBR2
        config.pingOn = true
        config.numOfSenders = 1
        config.logLevel = LiveKit.loggingLevelQuic.toQuicLogLevel()
        config.logHandler = Config.LogHandler { level, msg ->
            val loggingLevel = fromQuicLogLevel(level)

            try {
                val messageFormatted = stripQuicLogPrefix(msg)
                LKLog.log(loggingLevel, null) {
                    LKLog.withExternalPrefix { "[quic] $messageFormatted" }
                }
            } catch (_: Throwable) {
                // Swallowed deliberately: this runs on a native QUIC callback, where
                // throwing would take down the connection over a mere logging failure.
            }
        }
        return Connector(config)
    }

    @Provides
    fun signalTransportFactory(
        okHttpClient: OkHttpClient,
        ttsignalConnector: Connector,
    ): SignalTransport.Factory {
        return SignalTransport.Factory { options, attemptId, sendOnOpen ->
            if (options.useQuicSignal) {
                val quic = QuicTransport(attemptId, sendOnOpen, ttsignalConnector)
                QuicWithFallbackTransport(quic, okHttpClient)
            } else {
                WebSocketTransport(attemptId, sendOnOpen, okHttpClient)
            }
        }
    }

    @Provides
    @Named(InjectionNames.LOCAL_AUDIO_RECORD_SAMPLES_DISPATCHER)
    @Singleton
    fun localAudioSamplesDispatcher(): AudioRecordSamplesDispatcher {
        return AudioRecordSamplesDispatcher()
    }

    @Provides
    @Named(InjectionNames.LOCAL_AUDIO_BUFFER_CALLBACK_DISPATCHER)
    @Singleton
    fun localAudioBufferCallbackDispatcher(): AudioBufferCallbackDispatcher {
        return AudioBufferCallbackDispatcher()
    }

    @Provides
    @Singleton
    @JvmSuppressWildcards
    fun audioModule(
        @Named(InjectionNames.OVERRIDE_AUDIO_DEVICE_MODULE)
        audioDeviceModuleOverride: AudioDeviceModule?,
        @Named(InjectionNames.OVERRIDE_JAVA_AUDIO_DEVICE_MODULE_CUSTOMIZER)
        moduleCustomizer: ((builder: JavaAudioDeviceModule.Builder) -> Unit)?,
        audioOutputAttributes: AudioAttributes,
        appContext: Context,
        closeableManager: CloseableManager,
        communicationWorkaround: CommunicationWorkaround,
        @Named(InjectionNames.LOCAL_AUDIO_RECORD_SAMPLES_DISPATCHER)
        audioRecordSamplesDispatcher: AudioRecordSamplesDispatcher,
        @Named(InjectionNames.LOCAL_AUDIO_BUFFER_CALLBACK_DISPATCHER)
        audioBufferCallbackDispatcher: AudioBufferCallbackDispatcher,
    ): AudioDeviceModule {
        if (audioDeviceModuleOverride != null) {
            return audioDeviceModuleOverride
        }

        // Set audio record error callbacks.
        val audioRecordErrorCallback = object : JavaAudioDeviceModule.AudioRecordErrorCallback {
            override fun onWebRtcAudioRecordInitError(errorMessage: String?) {
                LKLog.e { "onWebRtcAudioRecordInitError: $errorMessage" }
            }

            override fun onWebRtcAudioRecordStartError(
                errorCode: JavaAudioDeviceModule.AudioRecordStartErrorCode?,
                errorMessage: String?,
            ) {
                LKLog.e { "onWebRtcAudioRecordStartError: $errorCode. $errorMessage" }
            }

            override fun onWebRtcAudioRecordError(errorMessage: String?) {
                LKLog.e { "onWebRtcAudioRecordError: $errorMessage" }
            }
        }

        val audioTrackErrorCallback = object : JavaAudioDeviceModule.AudioTrackErrorCallback {
            override fun onWebRtcAudioTrackInitError(errorMessage: String?) {
                LKLog.e { "onWebRtcAudioTrackInitError: $errorMessage" }
            }

            override fun onWebRtcAudioTrackStartError(
                errorCode: JavaAudioDeviceModule.AudioTrackStartErrorCode?,
                errorMessage: String?,
            ) {
                LKLog.e { "onWebRtcAudioTrackStartError: $errorCode. $errorMessage" }
            }

            override fun onWebRtcAudioTrackError(errorMessage: String?) {
                LKLog.e { "onWebRtcAudioTrackError: $errorMessage" }
            }
        }

        val audioRecordStateCallback: JavaAudioDeviceModule.AudioRecordStateCallback = object :
            JavaAudioDeviceModule.AudioRecordStateCallback {
            override fun onWebRtcAudioRecordStart() {
                LKLog.v { "Audio recording starts" }
            }

            override fun onWebRtcAudioRecordStop() {
                LKLog.v { "Audio recording stops" }
            }
        }

        // Set audio track state callbacks.
        val audioTrackStateCallback: JavaAudioDeviceModule.AudioTrackStateCallback = object :
            JavaAudioDeviceModule.AudioTrackStateCallback {
            override fun onWebRtcAudioTrackStart() {
                LKLog.v { "Audio playout starts" }
                communicationWorkaround.onStartPlayout()
            }

            override fun onWebRtcAudioTrackStop() {
                LKLog.v { "Audio playout stops" }
                communicationWorkaround.onStopPlayout()
            }
        }

        val useHardwareAudioProcessing = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q

        val builder = JavaAudioDeviceModule.builder(appContext)
            .setUseHardwareAcousticEchoCanceler(useHardwareAudioProcessing)
            .setUseHardwareNoiseSuppressor(useHardwareAudioProcessing)
            .setAudioRecordErrorCallback(audioRecordErrorCallback)
            .setAudioTrackErrorCallback(audioTrackErrorCallback)
            .setAudioRecordStateCallback(audioRecordStateCallback)
            .setAudioTrackStateCallback(audioTrackStateCallback)
            .setSamplesReadyCallback(audioRecordSamplesDispatcher)
            // VOICE_COMMUNICATION needs to be used for echo cancelling.
            .setAudioSource(MediaRecorder.AudioSource.VOICE_COMMUNICATION)
            .setAudioAttributes(audioOutputAttributes)
            .setAudioBufferCallback(audioBufferCallbackDispatcher)

        moduleCustomizer?.invoke(builder)
        return builder.createAudioDeviceModule()
            .apply { closeableManager.registerClosable { release() } }
    }

    @Provides
    fun audioPrewarmer(
        @Named(InjectionNames.OVERRIDE_DISABLE_AUDIO_PREWARM)
        disableAudioPrewarm: Boolean,
        audioDeviceModule: AudioDeviceModule,
    ): AudioRecordPrewarmer {
        return if (disableAudioPrewarm) {
            NoAudioRecordPrewarmer()
        } else if (audioDeviceModule is JavaAudioDeviceModule) {
            JavaAudioRecordPrewarmer(audioDeviceModule)
        } else {
            LKLog.w { "Custom audio device module detected. Audio record prewarming is not available." }
            NoAudioRecordPrewarmer()
        }
    }

    @Provides
    @Singleton
    fun eglBase(
        @Named(InjectionNames.OVERRIDE_EGL_BASE)
        eglBaseOverride: EglBase?,
        memoryManager: CloseableManager,
    ): EglBase {
        return eglBaseOverride ?: EglBase
            .create()
            .apply { memoryManager.registerClosable { release() } }
    }

    @Provides
    fun eglContext(eglBase: EglBase): EglBase.Context = eglBase.eglBaseContext

    @Provides
    fun videoEncoderFactory(
        @Suppress("UNUSED_PARAMETER")
        @Named(InjectionNames.LIB_WEBRTC_INITIALIZATION)
        webrtcInitialization: LibWebrtcInitialization,
        @Named(InjectionNames.OPTIONS_VIDEO_HW_ACCEL)
        videoHwAccel: Boolean,
        eglContext: EglBase.Context,
        @Named(InjectionNames.OVERRIDE_VIDEO_ENCODER_FACTORY)
        videoEncoderFactoryOverride: VideoEncoderFactory?,
    ): VideoEncoderFactory {
        return videoEncoderFactoryOverride ?: if (videoHwAccel) {
            CustomVideoEncoderFactory(
                eglContext,
                enableIntelVp8Encoder = true,
                enableH264HighProfile = false,
            )
        } else {
            SoftwareVideoEncoderFactory()
        }
    }

    @Provides
    @Singleton
    fun customAudioProcessingFactory(
        @Suppress("UNUSED_PARAMETER")
        @Named(InjectionNames.LIB_WEBRTC_INITIALIZATION)
        webrtcInitialization: LibWebrtcInitialization,
        @Named(InjectionNames.OVERRIDE_AUDIO_PROCESSOR_OPTIONS)
        audioProcessorOptions: AudioProcessorOptions?,
        closeableManager: CloseableManager,
    ): CustomAudioProcessingFactory {
        return CustomAudioProcessingFactory(audioProcessorOptions ?: AudioProcessorOptions())
            .apply { closeableManager.registerClosable(this) }
    }

    @Provides
    fun audioProcessingController(customAudioProcessingFactory: CustomAudioProcessingFactory): AudioProcessingController {
        return customAudioProcessingFactory
    }

    @Provides
    fun audioProcessingFactory(customAudioProcessingFactory: CustomAudioProcessingFactory): AudioProcessingFactory {
        return customAudioProcessingFactory.getAudioProcessingFactory()
    }

    @Provides
    fun videoDecoderFactory(
        @Suppress("UNUSED_PARAMETER")
        @Named(InjectionNames.LIB_WEBRTC_INITIALIZATION)
        webrtcInitialization: LibWebrtcInitialization,
        @Named(InjectionNames.OPTIONS_VIDEO_HW_ACCEL)
        videoHwAccel: Boolean,
        eglContext: EglBase.Context,
        @Named(InjectionNames.OVERRIDE_VIDEO_DECODER_FACTORY)
        videoDecoderFactoryOverride: VideoDecoderFactory?,
    ): VideoDecoderFactory {
        return videoDecoderFactoryOverride ?: if (videoHwAccel) {
            CustomVideoDecoderFactory(eglContext)
        } else {
            SoftwareVideoDecoderFactory()
        }
    }

    @Provides
    @Singleton
    fun peerConnectionFactoryManager(
        @Suppress("UNUSED_PARAMETER")
        @Named(InjectionNames.LIB_WEBRTC_INITIALIZATION)
        webrtcInitialization: LibWebrtcInitialization,
        audioDeviceModule: AudioDeviceModule,
        videoEncoderFactory: VideoEncoderFactory,
        videoDecoderFactory: VideoDecoderFactory,
        @Named(InjectionNames.OVERRIDE_PEER_CONNECTION_FACTORY_OPTIONS)
        peerConnectionFactoryOptions: PeerConnectionFactory.Options?,
        memoryManager: CloseableManager,
        audioProcessingFactory: AudioProcessingFactory,
    ): PeerConnectionFactoryManager {
        return executeBlockingOnRTCThread(LibWebrtcInitializationThreadToken) {
            val peerConnectionFactory = PeerConnectionFactory.builder()
                .setAudioDeviceModule(audioDeviceModule)
                .setAudioProcessingFactory(audioProcessingFactory)
                .setVideoEncoderFactory(videoEncoderFactory)
                .setVideoDecoderFactory(videoDecoderFactory)
                .apply {
                    if (peerConnectionFactoryOptions != null) {
                        setOptions(peerConnectionFactoryOptions)
                    }
                }
                .createPeerConnectionFactory()
            return@executeBlockingOnRTCThread PeerConnectionFactoryManager(peerConnectionFactory)
                .apply {
                    memoryManager.registerClosable {
                        executeOnRTCThread(RTCThreadTokenImpl(this)) {
                            dispose()
                        }
                    }
                }
        }!!
    }

    @Provides
    fun dataPacketCryptorManagerFactory(): DataPacketCryptorManager.Factory {
        return DataPacketCryptorManagerImpl.Factory
    }

    @Provides
    @Singleton
    fun peerConnectionFactory(
        peerConnectionFactoryManager: PeerConnectionFactoryManager,
    ): PeerConnectionFactory {
        return peerConnectionFactoryManager.peerConnectionFactory
    }

    @Provides
    @Reusable
    fun rtcThreadToken(
        peerConnectionFactoryManager: PeerConnectionFactoryManager,
    ): RTCThreadToken {
        return RTCThreadTokenImpl(peerConnectionFactoryManager)
    }

    @Provides
    @Named(InjectionNames.SENDER)
    fun senderCapabilitiesGetter(peerConnectionFactory: PeerConnectionFactory): CapabilitiesGetter {
        return { mediaType: MediaStreamTrack.MediaType ->
            peerConnectionFactory.getRtpSenderCapabilities(mediaType)
        }
    }

    @Provides
    @Named(InjectionNames.OPTIONS_VIDEO_HW_ACCEL)
    fun videoHwAccel() = true

    @Provides
    fun sdpFactory(): SdpFactory = SdpFactory.getInstance()
}

/**
 * Used to ensure [RTCModule.libWebrtcInitialization] is called prior to other methods.
 *
 * @suppress
 */
object LibWebrtcInitialization

/**
 * To be used **only** for initialization and creation of PeerConnectionFactories,
 * as those don't need the native threads and cannot deadlock.
 */
private object LibWebrtcInitializationThreadToken : RTCThreadToken {
    override val isDisposed: Boolean
        get() = false
}
