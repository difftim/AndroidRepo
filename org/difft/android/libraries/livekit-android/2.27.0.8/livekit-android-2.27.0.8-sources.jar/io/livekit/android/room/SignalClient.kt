/*
 * Copyright 2023-2026 LiveKit, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package io.livekit.android.room

import androidx.annotation.VisibleForTesting
import com.vdurmont.semver4j.Semver
import io.livekit.android.ConnectOptions
import io.livekit.android.RoomOptions
import io.livekit.android.dagger.InjectionNames
import io.livekit.android.room.participant.ParticipantTrackPermission
import io.livekit.android.room.track.Track
import io.livekit.android.room.transport.SignalTransport
import io.livekit.android.stats.NetworkInfo
import io.livekit.android.stats.getClientInfo
import io.livekit.android.util.CloseableCoroutineScope
import io.livekit.android.util.Either
import io.livekit.android.util.LKLog
import io.livekit.android.util.TimeoutException
import io.livekit.android.util.toHttpUrl
import io.livekit.android.util.toWebsocketUrl
import io.livekit.android.util.withDeadline
import io.livekit.android.webrtc.toProtoSessionDescription
import kotlinx.coroutines.CancellableContinuation
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.InternalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import livekit.LivekitModels
import livekit.LivekitModels.AudioTrackFeature
import livekit.LivekitRtc
import livekit.LivekitRtc.JoinResponse
import livekit.LivekitRtc.ReconnectResponse
import livekit.org.webrtc.IceCandidate
import livekit.org.webrtc.PeerConnection
import livekit.org.webrtc.SessionDescription
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okio.ByteString
import okio.ByteString.Companion.toByteString
import java.net.UnknownHostException
import java.security.cert.CertPathValidatorException
import java.security.cert.CertificateException
import java.util.Date
import javax.inject.Inject
import javax.inject.Named
import javax.inject.Singleton
import javax.net.ssl.SSLPeerUnverifiedException
import kotlin.time.Duration.Companion.milliseconds

/**
 * SignalClient to LiveKit WS servers
 * @suppress
 */
@OptIn(ExperimentalCoroutinesApi::class)
@Singleton
class SignalClient
@Inject
constructor(
    private val transportFactory: SignalTransport.Factory,
    private val json: Json,
    private val okHttpClient: OkHttpClient,
    @Named(InjectionNames.DISPATCHER_IO)
    private val ioDispatcher: CoroutineDispatcher,
    private val networkInfo: NetworkInfo,
) : SignalTransport.Listener {
    @Volatile
    var isConnected = false
        private set

    @Volatile
    internal var isQuicMarkedUnhealthy = false
        private set

    @Volatile
    private var transport: SignalTransport? = null

    @Volatile
    private var isReconnecting: Boolean = false
    var listener: Listener? = null
    internal var serverVersion: Semver? = null
    internal var serverInfo: ServerInfo? = null
    private var lastUrl: String? = null
    internal var lastToken: String? = null
    internal var lastOptions: ConnectOptions? = null
    private var lastRoomOptions: RoomOptions? = null

    // Correlate callbacks with the active connection attempt to avoid races
    private var currentAttemptId: Long = 0

    @Volatile
    private var activeAttemptId: Long = 0

    private var connectStartTime: Long = 0
    private fun isActiveTransport(transport: SignalTransport): Boolean {
        val currentTransport = this.transport
        return transport == currentTransport && transport.attemptId == activeAttemptId
    }

    private fun invalidateAttempt(attemptId: Long) {
        if (activeAttemptId == attemptId) {
            activeAttemptId = 0
        }

        val currentTransport = transport
        if (currentTransport?.attemptId == attemptId) {
            transport = null
        }
    }

    // join will always return a JoinResponse.
    // reconnect will return a ReconnectResponse or a Unit if a different response was received.
    @Volatile
    private var joinContinuation: CancellableContinuation<ConnectResult>? = null

    @Volatile
    private var joinContinuationAttemptId: Long = 0
    private val joinContinuationLock = Any()
    private lateinit var coroutineScope: CloseableCoroutineScope

    /**
     * @see [startRequestQueue]
     */
    private val requestFlow = MutableSharedFlow<LivekitRtc.SignalRequest>(Int.MAX_VALUE)
    private val requestFlowJobLock = Object()
    private var requestFlowJob: Job? = null

    /**
     * @see [onReadyForResponses]
     */
    private val responseFlow = MutableSharedFlow<Pair<SignalTransport, LivekitRtc.SignalResponse>>(Int.MAX_VALUE)
    private val responseFlowJobLock = Object()
    private var responseFlowJob: Job? = null

    private var pingJob: Job? = null
    private var pongJob: Job? = null
    private var pingTimeoutDurationMillis: Long = 0
    private var pingIntervalDurationMillis: Long = 0
    private var rtt: Long = 0

    var connectionState: ConnectionState = ConnectionState.DISCONNECTED

    private var lastConnectionException: Exception? = null

    /**
     * @throws Exception if fails to connect.
     */
    @Throws(Exception::class)
    suspend fun join(
        url: String,
        token: String,
        options: ConnectOptions = ConnectOptions(),
        roomOptions: RoomOptions = RoomOptions(),
    ): JoinResponse {
        return when (val result = connect(url, token, options, roomOptions)) {
            is ConnectResult.Join -> result.response
            else -> throw IllegalStateException("Unexpected response during join: $result")
        }
    }

    /**
     * @throws Exception if fails to connect.
     */
    @Throws(Exception::class)
    @VisibleForTesting
    suspend fun reconnect(url: String, token: String, participantSid: String?): Either<ReconnectResponse, Unit> {
        return when (
            val result = connect(
                url,
                token,
                (lastOptions ?: ConnectOptions()).copy()
                    .apply {
                        reconnect = true
                        this.participantSid = participantSid
                    },
                lastRoomOptions ?: RoomOptions(),
            )
        ) {
            is ConnectResult.Reconnect -> Either.Left(result.response)
            is ConnectResult.OtherResponse -> Either.Right(Unit)
            is ConnectResult.Join -> throw IllegalStateException("Unexpected join response during reconnect")
        }
    }

    private suspend fun connect(
        url: String,
        token: String,
        options: ConnectOptions,
        roomOptions: RoomOptions,
    ): ConnectResult {
        // Clean up any pre-existing connection.
        close(reason = "Starting new connection", shouldClearQueuedRequests = false)

        val effectiveOptions = effectiveConnectOptions(options)
        val wsUrlString = "${url.toWebsocketUrl()}/rtc${createConnectionParams(token, getClientInfo(effectiveOptions.clientProtocol), effectiveOptions, roomOptions)}"
        isReconnecting = effectiveOptions.reconnect

        LKLog.i { "connecting to $wsUrlString" }

        coroutineScope = CloseableCoroutineScope(SupervisorJob() + ioDispatcher)
        lastUrl = wsUrlString
        lastToken = token
        lastOptions = options
        lastRoomOptions = roomOptions

        // Increment attempt id to mark this connection try
        currentAttemptId += 1
        val attemptId = currentAttemptId
        activeAttemptId = attemptId

        val sendOnOpen = if (options.ttCallRequest != null && token.isEmpty()) {
            options.ttCallRequest.let { req ->
                LivekitRtc.SignalRequest.newBuilder().setTtCallRequest(req).build().toByteArray().toByteString()
            }
        } else {
            null
        }

        connectStartTime = System.currentTimeMillis()

        try {
            LKLog.i { "[reconnect][signal] connect - in, attempt=$attemptId" }
            val ret = connectWithTimeout(wsUrlString, token, effectiveOptions, attemptId, sendOnOpen)
            LKLog.i { "[reconnect][signal] connect - out, attempt=$attemptId" }
            return ret
        } catch (t: Throwable) {
            LKLog.i { "[reconnect][signal] connect - out with exception, attempt=$attemptId" }
            throw t
        }
    }

    private fun effectiveConnectOptions(options: ConnectOptions): ConnectOptions {
        if (!isQuicMarkedUnhealthy || !options.useQuicSignal) {
            return options
        }

        return options.copy(useQuicSignal = false).apply {
            reconnect = options.reconnect
            participantSid = options.participantSid
        }
    }

    internal fun resetQuicHealthForNewSession() {
        if (!isQuicMarkedUnhealthy) return

        isQuicMarkedUnhealthy = false
        LKLog.i { "[transport] resetting QUIC unhealthy marker for new session" }
    }

    private suspend fun connectWithTimeout(
        url: String,
        token: String,
        options: ConnectOptions,
        attemptId: Long,
        sendOnOpen: ByteString?,
    ): ConnectResult {
        return try {
            withDeadline(SIGNAL_CONNECT_TIMEOUT.milliseconds) {
                suspendCancellableCoroutine { it ->
                    // Wait for join/reconnect response via WebSocketListener
                    synchronized(joinContinuationLock) {
                        joinContinuation = it
                        joinContinuationAttemptId = attemptId
                    }

                    LKLog.i { "[reconnect][signal] new transport created - beg, attempt=$attemptId" }
                    val newTransport = transportFactory.create(options, attemptId, sendOnOpen)

                    it.invokeOnCancellation {
                        LKLog.i { "[reconnect][signal] the coroutine is cancelled or times out" }
                        invalidateAttempt(attemptId)
                        newTransport.cancel()
                        clearJoinContinuation(attemptId)
                    }

                    newTransport.connect(url, token, options, this@SignalClient)
                    transport = newTransport
                    LKLog.i { "[reconnect][signal] new transport created - end, attempt=$attemptId, transport=$newTransport" }
                }
            }
        } catch (t: TimeoutException) {
            // Timeout: close and propagate
            val localTransport = transport
            if (localTransport != null && localTransport.attemptId == attemptId && isActiveTransport(localTransport)) {
                LKLog.i { "[reconnect][signal] connect - out timeout exception, attempt=$attemptId, close transport=$localTransport" }
                // Immediately close
                invalidateAttempt(attemptId)
                localTransport.cancel()
            } else {
                invalidateAttempt(attemptId)
            }
            // Wrap kotlinx coroutine internal exception into a RoomException so callers
            // can handle it as a regular SDK exception without depending on coroutine internals,
            // and so it does not propagate as a CancellationException to the calling scope.
            throw RoomException.ConnectTimeoutException(
                message = "Timed out connecting to signal server after $SIGNAL_CONNECT_TIMEOUT ms",
                cause = t,
                timeoutMs = SIGNAL_CONNECT_TIMEOUT,
            )
        }
    }

    private fun clearJoinContinuation(attemptId: Long? = null): CancellableContinuation<ConnectResult>? {
        synchronized(joinContinuationLock) {
            if (attemptId != null && joinContinuationAttemptId != attemptId) {
                return null
            }

            val cont = joinContinuation
            joinContinuation = null
            joinContinuationAttemptId = 0
            return cont
        }
    }

    @OptIn(InternalCoroutinesApi::class)
    private fun failJoinContinuation(attemptId: Long? = null, error: Throwable? = null) {
        val cont = clearJoinContinuation(attemptId)
        if (cont != null) {
            if (error != null) {
                cont.tryResumeWithException(error)?.let { token ->
                    cont.completeResume(token)
                }
            } else {
                cont.cancel()
            }
        }
    }

    private fun resumeJoinContinuation(attemptId: Long, value: ConnectResult) {
        clearJoinContinuation(attemptId)?.resumeWith(Result.success(value))
    }

    private fun createConnectionParams(
        token: String,
        clientInfo: LivekitModels.ClientInfo,
        options: ConnectOptions,
        roomOptions: RoomOptions,
    ): String {
        val queryBuilder = StringBuilder()
        var first = true

        fun addParam(key: String, value: String) {
            queryBuilder.append(if (first) "?" else "&")
                .append(key).append("=").append(value)
            first = false
        }

        addParam(CONNECT_QUERY_PROTOCOL, options.protocolVersion.value.toString())

        if (options.reconnect) {
            addParam(CONNECT_QUERY_RECONNECT, "1")
            options.participantSid?.let { sid ->
                addParam(CONNECT_QUERY_PARTICIPANT_SID, sid)
            }
        }

        val autoSubscribe = if (options.autoSubscribe) 1 else 0
        addParam(CONNECT_QUERY_AUTOSUBSCRIBE, autoSubscribe.toString())

        val adaptiveStream = if (roomOptions.adaptiveStream) 1 else 0
        addParam(CONNECT_QUERY_ADAPTIVE_STREAM, adaptiveStream.toString())

        // Client info
        addParam(CONNECT_QUERY_SDK, "android")
        addParam(CONNECT_QUERY_VERSION, clientInfo.version)
        addParam(CONNECT_QUERY_DEVICE_MODEL, clientInfo.deviceModel)
        addParam(CONNECT_QUERY_OS, clientInfo.os)
        addParam(CONNECT_QUERY_OS_VERSION, clientInfo.osVersion)
        addParam(CONNECT_QUERY_NETWORK_TYPE, networkInfo.getNetworkType().protoName)
        addParam(CONNECT_QUERY_CLIENT_PROTOCOL, options.clientProtocol.value.toString())

        if (options.ttCallRequest != null && token.isEmpty()) {
            addParam(CONNECT_QUERY_TT_VERSION, "1")
        }

        return queryBuilder.toString()
    }

    /**
     * Notifies that the downstream consumers of SignalClient are ready to consume messages.
     * Until this method is called, any messages received through the websocket are buffered.
     *
     * Should be called after resolving the join message.
     */
    fun onReadyForResponses() {
        if (responseFlowJob != null) {
            return
        }
        synchronized(responseFlowJobLock) {
            if (responseFlowJob == null) {
                responseFlowJob = coroutineScope.launch {
                    responseFlow.collect { (transport, response) ->
                        responseFlow.resetReplayCache()
                        handleSignalResponseImpl(transport, response)
                    }
                }
            }
        }
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    private fun startRequestQueue() {
        if (requestFlowJob != null) {
            return
        }
        synchronized(requestFlowJobLock) {
            if (requestFlowJob == null) {
                requestFlowJob = coroutineScope.launch {
                    requestFlow.collect {
                        requestFlow.resetReplayCache()
                        sendRequestImpl(it)
                    }
                }
            }
        }
    }

    /**
     * On reconnection, SignalClient waits until the peer connection is established to send messages.
     * Call this method when it is connected.
     */
    fun onPCConnected() {
        startRequestQueue()
    }

    // ---------------------------------SignalTransport  Listener --------------------------------------//
    override fun onOpen(transport: SignalTransport) {
        LKLog.i { "[reconnect][signal] transport onOpen(${System.currentTimeMillis() - connectStartTime}) send=${transport.sendOnOpen != null}, transport=$transport" }
        if (!isActiveTransport(transport)) {
            LKLog.i { "[reconnect][signal] transport onOpen ignored (stale) [aliveAttempt=$currentAttemptId] ts=$transport" }
            return
        }

        markQuicUnhealthyIfFallback(transport)

        transport.sendOnOpen?.let { req ->
            transport.send(req)
        }
    }

    private fun markQuicUnhealthyIfFallback(transport: SignalTransport) {
        if (!transport.isFallbackTransport) {
            return
        }
        if (isQuicMarkedUnhealthy) {
            return
        }

        isQuicMarkedUnhealthy = true
        LKLog.w { "[transport] marking QUIC unhealthy for this session; using WebSocket later" }
    }

    override fun onMessage(transport: SignalTransport, message: ByteString) {
        if (!isActiveTransport(transport)) {
            // Possibly message from old websocket, discard.
            return
        }
        val byteArray = message.toByteArray()
        val response = try {
            LivekitRtc.SignalResponse.newBuilder()
                .mergeFrom(byteArray)
                .build()
        } catch (e: com.google.protobuf.InvalidProtocolBufferException) {
            LKLog.w(e) { "Failed to parse SignalResponse, discarding malformed message." }
            return
        }

        handleSignalResponse(transport, response)
    }

    override fun onClosed(transport: SignalTransport, code: Int, reason: String) {
        val stale = !isActiveTransport(transport)
        LKLog.i { "[reconnect][signal] transport onClosed \"${if (stale) "ignored (stale) " else ""}\" code=$code, transport=$transport, reason=$reason" }

        if (stale) {
            return
        }
        handleWebSocketClose(transport, reason, code)
    }

    override fun onClosing(transport: SignalTransport, code: Int, reason: String) {
        LKLog.i { "[reconnect][signal] transport closing, transport=$transport" }
    }

    override fun onFailure(transport: SignalTransport, t: Throwable, response: Response?) {
        val stale = !isActiveTransport(transport)
        LKLog.i(t) { "[reconnect][signal] transport failure \"${if (stale) "ignored (stale) " else ""}\" currentTs=${this.transport}, transport=$transport, response=$response" }

        if (stale) {
            return
        }
        var exceptionError: Exception? = lastConnectionException.also { lastConnectionException = null }
        val validationToken = lastToken
        try {
            if (exceptionError == null) {
                when {
                    t.hasUnknownHostCause() -> {
                        LKLog.i { "[reconnect][signal] skipping connection validation for UnknownHostException" }
                    }
                    t.hasCertificateValidationCause() -> {
                        LKLog.i { "[reconnect][signal] skipping connection validation for certificate failure" }
                    }
                    validationToken.isNullOrBlank() -> {
                        LKLog.i { "[reconnect][signal] skipping connection validation because token is blank" }
                    }
                    else -> {
                        lastUrl?.let {
                            val validationUrl = it.toHttpUrl().replaceFirst("/rtc?", "/rtc/validate?")
                            val request = Request.Builder()
                                .url(validationUrl)
                                .addHeader("Authorization", "Bearer $validationToken")
                                .build()
                            okHttpClient.newCall(request).execute().use { resp ->
                                val body = resp.body
                                if (!resp.isSuccessful) {
                                    val reason = body?.string()
                                    exceptionError = if (resp.code == 401) {
                                        RoomException.NoAuthException(reason)
                                    } else {
                                        Exception(reason)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } catch (e: Throwable) {
            LKLog.e { "failed to validate connection" }
        }

        if (!isActiveTransport(transport)) {
            LKLog.i { "[reconnect][signal] transport failure ignored after validation (stale), transport=$transport" }
            return
        }

        val wasConnected = isConnected
        val wasReconnectHandshake = joinContinuation != null && isReconnecting

        val error = exceptionError
        if (error != null) {
            LKLog.e { "transport failure(reason): $error" }
            listener?.onError(error)
            failJoinContinuation(transport.attemptId, error)
        } else {
            LKLog.e { "transport failure(response): $response" }
            listener?.onError(t)
            failJoinContinuation(transport.attemptId, t)
        }

        if (wasConnected || wasReconnectHandshake) {
            // onClosing/onClosed will not be called after onFailure.
            // Handle websocket closure here.
            // Also handle failure during a soft reconnect handshake (reconnect query): isConnected is
            // still false but the upper layer should be notified like a close. Initial join handshake
            // failures do not call onClose so RTCEngine can surface them via onError / onFailToConnect.
            handleWebSocketClose(
                transport = transport,
                reason = error?.message ?: response?.toString() ?: t.localizedMessage ?: "transport failure",
                code = response?.code ?: CLOSE_REASON_WEBSOCKET_FAILURE,
            )
        }
    }

    override fun onRestarted(transport: SignalTransport, result: Int, address: String?) {
        if (!isActiveTransport(transport)) {
            return
        }
        LKLog.i { "[reconnect][quic] transport restarted, result=$result, address=$address" }
        listener?.onTransportRestarted(result, address)
    }

    private fun Throwable.hasCertificateValidationCause(): Boolean {
        var current: Throwable? = this
        val visited = HashSet<Throwable>()
        while (current != null && visited.add(current)) {
            when (current) {
                is CertificateException,
                is CertPathValidatorException,
                is SSLPeerUnverifiedException -> return true
            }
            current = current.cause
        }
        return false
    }

    private fun Throwable.hasUnknownHostCause(): Boolean {
        var current: Throwable? = this
        while (current != null) {
            if (current is UnknownHostException) {
                return true
            }
            current = current.cause
        }
        return false
    }

    private fun handleWebSocketClose(transport: SignalTransport, reason: String, code: Int) {
        LKLog.i { "[reconnect][signal] websocket closed reason=$reason, code=$code" }
        isConnected = false
        requestFlow.resetReplayCache()
        responseFlow.resetReplayCache()
        pingJob?.cancel()
        pongJob?.cancel()
        // If connect() is still waiting, cancel it to avoid hanging
        failJoinContinuation(transport.attemptId, Exception("websocket closed before connected: $reason (code=$code)"))
        listener?.onClose(reason, code)
    }

    // ------------------------------- End WebSocket Listener ------------------------------------//

    private fun fromProtoSessionDescription(sd: LivekitRtc.SessionDescription): SessionDescription {
        val rtcSdpType = when (sd.type) {
            SD_TYPE_ANSWER -> SessionDescription.Type.ANSWER
            SD_TYPE_OFFER -> SessionDescription.Type.OFFER
            SD_TYPE_PRANSWER -> SessionDescription.Type.PRANSWER
            SD_TYPE_ROLLBACK -> SessionDescription.Type.ROLLBACK
            else -> throw IllegalArgumentException("invalid RTC SdpType: ${sd.type}")
        }
        return SessionDescription(rtcSdpType, sd.sdp)
    }

    fun sendOffer(offer: SessionDescription, offerId: Int) {
        val sd = offer.toProtoSessionDescription(offerId)
        val request = LivekitRtc.SignalRequest.newBuilder()
            .setOffer(sd)
            .build()

        sendRequest(request)
    }

    fun sendAnswer(answer: SessionDescription, offerId: Int) {
        val sd = answer.toProtoSessionDescription(offerId)
        val request = LivekitRtc.SignalRequest.newBuilder()
            .setAnswer(sd)
            .build()

        sendRequest(request)
    }

    fun sendCandidate(candidate: IceCandidate, target: LivekitRtc.SignalTarget) {
        val iceCandidateJSON = IceCandidateJSON(
            candidate = candidate.sdp,
            sdpMid = candidate.sdpMid,
            sdpMLineIndex = candidate.sdpMLineIndex,
        )

        val trickleRequest = LivekitRtc.TrickleRequest.newBuilder()
            .setCandidateInit(json.encodeToString(iceCandidateJSON))
            .setTarget(target)
            .build()

        val request = LivekitRtc.SignalRequest.newBuilder()
            .setTrickle(trickleRequest)
            .build()

        sendRequest(request)
    }

    fun sendMuteTrack(trackSid: String, muted: Boolean) {
        val muteRequest = LivekitRtc.MuteTrackRequest.newBuilder()
            .setSid(trackSid)
            .setMuted(muted)
            .build()

        val request = LivekitRtc.SignalRequest.newBuilder()
            .setMute(muteRequest)
            .build()

        sendRequest(request)
    }

    /**
     * @param builder an optional builder to include other parameters related to the track
     */
    fun sendAddTrack(
        cid: String,
        name: String,
        type: LivekitModels.TrackType,
        stream: String?,
        builder: LivekitRtc.AddTrackRequest.Builder = LivekitRtc.AddTrackRequest.newBuilder(),
    ) {
        val encryptionType = lastRoomOptions?.e2eeOptions?.encryptionType ?: LivekitModels.Encryption.Type.NONE
        val addTrackRequest = builder.apply {
            setCid(cid)
            setName(name)
            setType(type)
            if (stream != null) {
                setStream(stream)
            } else {
                clearStream()
            }
            encryption = encryptionType
        }
        val request = LivekitRtc.SignalRequest.newBuilder()
            .setAddTrack(addTrackRequest)
            .build()

        sendRequest(request)
    }

    fun sendUpdateTrackSettings(
        sid: String,
        disabled: Boolean,
        videoDimensions: Track.Dimensions?,
        videoQuality: LivekitModels.VideoQuality?,
        fps: Int?,
    ) {
        val trackSettings = LivekitRtc.UpdateTrackSettings.newBuilder()
            .addTrackSids(sid)
            .setDisabled(disabled)
            .apply {
                if (videoDimensions != null) {
                    width = videoDimensions.width
                    height = videoDimensions.height
                } else if (videoQuality != null) {
                    quality = videoQuality
                } else {
                    // default to HIGH
                    quality = LivekitModels.VideoQuality.HIGH
                }

                if (fps != null) {
                    setFps(fps)
                }
            }

        val request = LivekitRtc.SignalRequest.newBuilder()
            .setTrackSetting(trackSettings)
            .build()

        sendRequest(request)
    }

    fun sendUpdateSubscription(subscribe: Boolean, vararg participantTracks: LivekitModels.ParticipantTracks) {
        val participantTracksList = participantTracks.toList()

        // backwards compatibility for protocol version < 6
        val trackSids = participantTracksList.map { it.trackSidsList }.flatten()
        val subscription = LivekitRtc.UpdateSubscription.newBuilder()
            .addAllParticipantTracks(participantTracks.toList())
            .addAllTrackSids(trackSids)
            .setSubscribe(subscribe)

        val request = LivekitRtc.SignalRequest.newBuilder()
            .setSubscription(subscription)
            .build()

        sendRequest(request)
    }

    fun sendUpdateSubscriptionPermissions(
        allParticipants: Boolean,
        participantTrackPermissions: List<ParticipantTrackPermission>,
    ) {
        val update = LivekitRtc.SubscriptionPermission.newBuilder()
            .setAllParticipants(allParticipants)
            .addAllTrackPermissions(participantTrackPermissions.map { it.toProto() })

        val request = LivekitRtc.SignalRequest.newBuilder()
            .setSubscriptionPermission(update)
            .build()

        sendRequest(request)
    }

    fun sendUpdateLocalMetadata(metadata: String?, name: String?, attributes: Map<String, String>? = emptyMap()) {
        val update = LivekitRtc.UpdateParticipantMetadata.newBuilder()
            .setMetadata(metadata ?: "")
            .setName(name ?: "")
            .putAllAttributes(attributes)

        val request = LivekitRtc.SignalRequest.newBuilder()
            .setUpdateMetadata(update)
            .build()

        sendRequest(request)
    }

    fun sendSyncState(syncState: LivekitRtc.SyncState) {
        val request = LivekitRtc.SignalRequest.newBuilder()
            .setSyncState(syncState)
            .build()

        sendRequest(request)
    }

    internal fun sendSimulateScenario(scenario: LivekitRtc.SimulateScenario) {
        val request = LivekitRtc.SignalRequest.newBuilder()
            .setSimulate(scenario)
            .build()

        sendRequest(request)
    }

    fun sendLeave() {
        val request = with(LivekitRtc.SignalRequest.newBuilder()) {
            leave = with(LivekitRtc.LeaveRequest.newBuilder()) {
                reason = LivekitModels.DisconnectReason.CLIENT_INITIATED
                // server doesn't process this field, keeping it here to indicate the intent of a full disconnect
                action = LivekitRtc.LeaveRequest.Action.DISCONNECT
                build()
            }
            build()
        }

        sendRequest(request)
    }

    fun sendPing(): Long {
        val time = Date().time
        sendRequest(
            with(LivekitRtc.SignalRequest.newBuilder()) {
                ping = time
                build()
            },
        )
        sendRequest(
            with(LivekitRtc.SignalRequest.newBuilder()) {
                pingReq = with(LivekitRtc.Ping.newBuilder()) {
                    rtt = this@SignalClient.rtt
                    timestamp = time
                    build()
                }
                build()
            },
        )

        return time
    }

    fun sendUpdateLocalAudioTrack(trackSid: String, features: Collection<AudioTrackFeature>) {
        val request = with(LivekitRtc.SignalRequest.newBuilder()) {
            updateAudioTrack = with(LivekitRtc.UpdateLocalAudioTrack.newBuilder()) {
                setTrackSid(trackSid)
                addAllFeatures(features)
                build()
            }
            build()
        }

        sendRequest(request)
    }

    private fun sendRequest(request: LivekitRtc.SignalRequest) {
        val skipQueue = skipQueueTypes.contains(request.messageCase)

        if (skipQueue) {
            sendRequestImpl(request)
        } else {
            requestFlow.tryEmit(request)
        }
    }

    private fun sendRequestImpl(request: LivekitRtc.SignalRequest) {
        LKLog.v { "sending request: $request" }
        if (!isConnected || transport == null) {
            LKLog.w { "not connected, could not send request $request" }
            return
        }
        val message = request.toByteArray().toByteString()
        val sent = transport?.send(message) ?: false

        if (!sent) {
            LKLog.e { "error sending request: $request" }
        }
    }

    private fun handleSignalResponse(transport: SignalTransport, response: LivekitRtc.SignalResponse) {
        if (!isActiveTransport(transport)) {
            return
        }

        LKLog.v { "response: $response" }

        if (!isConnected) {
            var shouldProcessMessage = false

            // Only handle certain messages if not connected.
            if (response.hasJoin()) {
                response.join.ttCallResponse?.let { tt ->
                    if (tt.base.status != 0) {
                        // server will close after joinResponse
                        lastConnectionException = RoomException.StartCallException(tt.base.reason, null, tt.base.status)
                        return
                    }
                }

                isConnected = true
                startRequestQueue()
                pingTimeoutDurationMillis = response.join.pingTimeout.toLong() * 1000
                pingIntervalDurationMillis = response.join.pingInterval.toLong() * 1000
                startPingJob()
                try {
                    serverVersion = Semver(response.join.serverVersion)
                } catch (t: Throwable) {
                    LKLog.w(t) { "Thrown while trying to parse server version." }
                }
                LKLog.i { "[quic] joinResponse:  ${System.currentTimeMillis() - connectStartTime}" }
                serverInfo = ServerInfo(
                    edition = ServerInfo.Edition.fromProto(response.join.serverInfo.edition),
                    version = serverVersion,
                )
                resumeJoinContinuation(transport.attemptId, ConnectResult.Join(response.join))
            } else if (response.hasLeave()) {
                if (!isConnected) {
                    failJoinContinuation(
                        transport.attemptId,
                        Exception(
                            "signal reconnect interrupted by server leave: " +
                                "${response.leave.action.name}/${response.leave.reason.name}",
                        ),
                    )
                }
                // Some reconnects may immediately send leave back without a join response first.
                handleSignalResponseImpl(transport, response)
            } else if (isReconnecting) {
                // When reconnecting, any message received means signal reconnected.
                // Newer servers will send a reconnect response first
                isReconnecting = false
                isConnected = true

                // Restart ping job with old settings.
                startPingJob()

                if (response.hasReconnect()) {
                    if (response.reconnect.hasServerInfo()) {
                        try {
                            serverVersion = Semver(response.reconnect.serverInfo.version)
                        } catch (t: Throwable) {
                            LKLog.w(t) { "Thrown while trying to parse server version from reconnect." }
                        }
                        serverInfo = ServerInfo(
                            edition = ServerInfo.Edition.fromProto(response.reconnect.serverInfo.edition),
                            version = serverVersion,
                        )
                    }
                    resumeJoinContinuation(transport.attemptId, ConnectResult.Reconnect(response.reconnect))
                } else {
                    resumeJoinContinuation(transport.attemptId, ConnectResult.OtherResponse)
                    // Non-reconnect response, handle normally
                    shouldProcessMessage = true
                }
            } else {
                LKLog.e { "Received response while not connected. $response" }
            }
            if (!shouldProcessMessage) {
                return
            }
        }
        responseFlow.tryEmit(transport to response)
    }

    private fun handleSignalResponseImpl(transport: SignalTransport, response: LivekitRtc.SignalResponse) {
        if (!isActiveTransport(transport)) {
            LKLog.v { "received message from old transport, discarding." }
            return
        }

        when (response.messageCase) {
            LivekitRtc.SignalResponse.MessageCase.ANSWER -> {
                val sd = fromProtoSessionDescription(response.answer)
                val offerId = response.answer.id
                listener?.onServerAnswer(sd, offerId)
            }

            LivekitRtc.SignalResponse.MessageCase.OFFER -> {
                val sd = fromProtoSessionDescription(response.offer)
                val offerId = response.offer.id
                listener?.onServerOffer(sd, offerId)
            }

            LivekitRtc.SignalResponse.MessageCase.TRICKLE -> {
                val iceCandidateJson =
                    json.decodeFromString<IceCandidateJSON>(response.trickle.candidateInit)
                val iceCandidate = IceCandidate(
                    iceCandidateJson.sdpMid,
                    iceCandidateJson.sdpMLineIndex,
                    iceCandidateJson.candidate,
                )
                listener?.onTrickle(iceCandidate, response.trickle.target)
            }

            LivekitRtc.SignalResponse.MessageCase.UPDATE -> {
                listener?.onParticipantUpdate(response.update.participantsList)
            }

            LivekitRtc.SignalResponse.MessageCase.TRACK_SUBSCRIBED -> {
                listener?.onLocalTrackSubscribed(response.trackSubscribed)
            }

            LivekitRtc.SignalResponse.MessageCase.TRACK_PUBLISHED -> {
                listener?.onLocalTrackPublished(response.trackPublished)
            }

            LivekitRtc.SignalResponse.MessageCase.SPEAKERS_CHANGED -> {
                listener?.onSpeakersChanged(response.speakersChanged.speakersList)
            }

            LivekitRtc.SignalResponse.MessageCase.JOIN -> {
                LKLog.d { "received unexpected extra join message?" }
            }

            LivekitRtc.SignalResponse.MessageCase.LEAVE -> {
                listener?.onLeave(response.leave)
            }

            LivekitRtc.SignalResponse.MessageCase.MUTE -> {
                listener?.onRemoteMuteChanged(response.mute.sid, response.mute.muted)
            }

            LivekitRtc.SignalResponse.MessageCase.ROOM_UPDATE -> {
                listener?.onRoomUpdate(response.roomUpdate.room)
            }

            LivekitRtc.SignalResponse.MessageCase.CONNECTION_QUALITY -> {
                listener?.onConnectionQuality(response.connectionQuality.updatesList)
            }

            LivekitRtc.SignalResponse.MessageCase.STREAM_STATE_UPDATE -> {
                listener?.onStreamStateUpdate(response.streamStateUpdate.streamStatesList)
            }

            LivekitRtc.SignalResponse.MessageCase.SUBSCRIBED_QUALITY_UPDATE -> {
                val versionToIgnoreUpTo = Semver("0.15.1")
                if ((serverVersion?.compareTo(versionToIgnoreUpTo) ?: 1) <= 0) {
                    return
                }
                listener?.onSubscribedQualityUpdate(response.subscribedQualityUpdate)
            }

            LivekitRtc.SignalResponse.MessageCase.SUBSCRIPTION_PERMISSION_UPDATE -> {
                listener?.onSubscriptionPermissionUpdate(response.subscriptionPermissionUpdate)
            }

            LivekitRtc.SignalResponse.MessageCase.REFRESH_TOKEN -> {
                LKLog.d { "REFRESH_TOKEN: response" }
                lastToken = response.refreshToken

                listener?.onRefreshToken(response.refreshToken)
            }

            LivekitRtc.SignalResponse.MessageCase.TRACK_UNPUBLISHED -> {
                listener?.onLocalTrackUnpublished(response.trackUnpublished)
            }

            LivekitRtc.SignalResponse.MessageCase.PONG -> {
                resetPingTimeout()
            }

            LivekitRtc.SignalResponse.MessageCase.PONG_RESP -> {
                rtt = Date().time - response.pongResp.lastPingTimestamp
                resetPingTimeout()
            }

            LivekitRtc.SignalResponse.MessageCase.RECONNECT -> {
                // Handshake-only message; handled in handleSignalResponse() before connection.
                LKLog.d { "ignoring reconnect response received after connected" }
            }

            LivekitRtc.SignalResponse.MessageCase.SUBSCRIPTION_RESPONSE -> {
                listener?.onSubscriptionError(response.subscriptionResponse)
            }

            LivekitRtc.SignalResponse.MessageCase.REQUEST_RESPONSE -> {
                // TODO
            }

            LivekitRtc.SignalResponse.MessageCase.ROOM_MOVED -> {
                // TODO
            }

            LivekitRtc.SignalResponse.MessageCase.MEDIA_SECTIONS_REQUIREMENT -> {
                // TODO
            }

            LivekitRtc.SignalResponse.MessageCase.SUBSCRIBED_AUDIO_CODEC_UPDATE -> {
                // TODO
            }

            LivekitRtc.SignalResponse.MessageCase.PUBLISH_DATA_TRACK_RESPONSE -> {
                // TODO
            }

            LivekitRtc.SignalResponse.MessageCase.UNPUBLISH_DATA_TRACK_RESPONSE -> {
                // TODO
            }

            LivekitRtc.SignalResponse.MessageCase.DATA_TRACK_SUBSCRIBER_HANDLES -> {
                // TODO
            }

            LivekitRtc.SignalResponse.MessageCase.MESSAGE_NOT_SET,
            null,
            -> {
                LKLog.v { "empty messageCase!" }
            }
        }
    }

    private fun startPingJob() {
        if (pingJob == null && pingIntervalDurationMillis != 0L) {
            pingJob = coroutineScope.launch {
                while (true) {
                    delay(pingIntervalDurationMillis)
                    val pingTimestamp = sendPing()
                    startPingTimeout(pingTimestamp)
                }
            }
        }
    }

    private fun startPingTimeout(timestamp: Long) {
        if (pongJob != null) {
            return
        }
        pongJob = coroutineScope.launch {
            delay(pingTimeoutDurationMillis)
            LKLog.d { "Ping timeout reached for ping sent at $timestamp." }
            transport?.cancel()
        }
    }

    private fun resetPingTimeout() {
        pongJob?.cancel()
        pongJob = null
    }

    /**
     * Requests the active transport to migrate to a new network path (QUIC connection migration).
     */
    fun restartTransport(networkHandle: Long) {
        LKLog.i { "[reconnect][quic] restartTransport called, networkHandle=$networkHandle, transport=$transport" }
        transport?.restart(networkHandle)
    }

    /**
     * Closes out any existing websocket connection, and cleans up used resources.
     *
     * Can be reused afterwards.
     */
    fun close(code: Int = CLOSE_REASON_NORMAL_CLOSURE, reason: String = "Normal Closure", shouldClearQueuedRequests: Boolean = true) {
        LKLog.i { "Closing SignalClient: code = $code, reason = $reason" }
        isConnected = false
        isReconnecting = false
        activeAttemptId = 0
        if (::coroutineScope.isInitialized) {
            coroutineScope.close()
        }
        requestFlowJob?.cancel()
        requestFlowJob = null
        responseFlowJob?.cancel()
        responseFlowJob = null
        pingJob?.cancel()
        pingJob = null
        pongJob?.cancel()
        pongJob = null

        val holdingTs = transport
        transport = null
        holdingTs?.cancel()

        failJoinContinuation()
        if (shouldClearQueuedRequests) {
            requestFlow.resetReplayCache()
        }
        responseFlow.resetReplayCache()
        lastUrl = null
        lastToken = null
        lastOptions = null
        lastRoomOptions = null
        serverVersion = null
        serverInfo = null
    }

    interface Listener {
        fun onServerAnswer(sessionDescription: SessionDescription, offerId: Int)
        fun onServerOffer(sessionDescription: SessionDescription, offerId: Int)
        fun onTrickle(candidate: IceCandidate, target: LivekitRtc.SignalTarget)
        fun onLocalTrackPublished(response: LivekitRtc.TrackPublishedResponse)
        fun onParticipantUpdate(updates: List<LivekitModels.ParticipantInfo>)
        fun onSpeakersChanged(speakers: List<LivekitModels.SpeakerInfo>)
        fun onClose(reason: String, code: Int)
        fun onRemoteMuteChanged(trackSid: String, muted: Boolean)
        fun onRoomUpdate(update: LivekitModels.Room)
        fun onConnectionQuality(updates: List<LivekitRtc.ConnectionQualityInfo>)
        fun onLeave(leave: LivekitRtc.LeaveRequest)
        fun onError(error: Throwable)
        fun onStreamStateUpdate(streamStates: List<LivekitRtc.StreamStateInfo>)
        fun onSubscribedQualityUpdate(subscribedQualityUpdate: LivekitRtc.SubscribedQualityUpdate)
        fun onSubscriptionPermissionUpdate(subscriptionPermissionUpdate: LivekitRtc.SubscriptionPermissionUpdate)
        fun onSubscriptionError(subscriptionResponse: LivekitRtc.SubscriptionResponse)
        fun onRefreshToken(token: String)
        fun onLocalTrackUnpublished(trackUnpublished: LivekitRtc.TrackUnpublishedResponse)
        fun onLocalTrackSubscribed(trackSubscribed: LivekitRtc.TrackSubscribed)
        fun onTransportRestarted(result: Int, address: String?) {}
    }

    /**
     * Result of waiting for the initial signal response after opening the WebSocket.
     * Join always yields [Join]; reconnect yields [Reconnect] or [OtherResponse].
     */
    private sealed class ConnectResult {
        data class Join(val response: JoinResponse) : ConnectResult()
        data class Reconnect(val response: ReconnectResponse) : ConnectResult()
        data object OtherResponse : ConnectResult()
    }

    companion object {
        const val CONNECT_QUERY_RECONNECT = "reconnect"
        const val CONNECT_QUERY_AUTOSUBSCRIBE = "auto_subscribe"
        const val CONNECT_QUERY_ADAPTIVE_STREAM = "adaptive_stream"
        const val CONNECT_QUERY_SDK = "sdk"
        const val CONNECT_QUERY_VERSION = "version"
        const val CONNECT_QUERY_PROTOCOL = "protocol"
        const val CONNECT_QUERY_DEVICE_MODEL = "device_model"
        const val CONNECT_QUERY_OS = "os"
        const val CONNECT_QUERY_OS_VERSION = "os_version"
        const val CONNECT_QUERY_NETWORK_TYPE = "network"
        const val CONNECT_QUERY_PARTICIPANT_SID = "sid"
        const val CONNECT_QUERY_TT_VERSION = "tt_version"
        const val CONNECT_QUERY_CLIENT_PROTOCOL = "client_protocol"

        const val SD_TYPE_ANSWER = "answer"
        const val SD_TYPE_OFFER = "offer"
        const val SD_TYPE_PRANSWER = "pranswer"
        const val SD_TYPE_ROLLBACK = "rollback"
        const val SDK_TYPE = "android"

        private val skipQueueTypes = listOf(
            LivekitRtc.SignalRequest.MessageCase.SYNC_STATE,
            LivekitRtc.SignalRequest.MessageCase.TRICKLE,
            LivekitRtc.SignalRequest.MessageCase.OFFER,
            LivekitRtc.SignalRequest.MessageCase.ANSWER,
            LivekitRtc.SignalRequest.MessageCase.SIMULATE,
            LivekitRtc.SignalRequest.MessageCase.LEAVE,
        )

        private fun iceServer(url: String) =
            PeerConnection.IceServer.builder(url).createIceServer()

        // more stun servers might slow it down, WebRTC recommends 3 max
        val DEFAULT_ICE_SERVERS = listOf(
            iceServer("stun:stun.l.google.com:19302"),
            iceServer("stun:stun1.l.google.com:19302"),
//            iceServer("stun:stun2.l.google.com:19302"),
//            iceServer("stun:stun3.l.google.com:19302"),
//            iceServer("stun:stun4.l.google.com:19302"),
        )
        private const val SIGNAL_CONNECT_TIMEOUT: Long = 15000
        const val CLOSE_REASON_NORMAL_CLOSURE = 1000
        const val CLOSE_REASON_PING_TIMEOUT = 3000
        const val CLOSE_REASON_WEBSOCKET_FAILURE = 3500
    }
}

@Suppress("EnumEntryName", "unused")
enum class ProtocolVersion(val value: Int) {
    v1(1),
    v2(2),
    v3(3),
    v4(4),
    v5(5),
    v6(6),
    v7(7),
    v8(8),
    v9(9),
    v10(10),
    v11(11),
    v12(12),

    // new leave request handling
    v13(13),
}

/**
 * The protocol version this SDK advertises to **peers** (other participants) for
 * client-to-client feature negotiation (RPC v2, etc.). Distinct from [ProtocolVersion],
 * which tracks the signaling protocol between client and server.
 *
 * Sent to the server during the join handshake via the `client_protocol` connection
 * query parameter and `ClientInfo.client_protocol`; the server then populates
 * `ParticipantInfo.client_protocol` for other peers in the room to read.
 */
@Suppress("unused")
enum class ClientProtocolVersion(val value: Int) {
    /** Initial client protocol. RPC v1 only (15 KB packet payload limit). */
    DEFAULT(0),

    /**
     * RPC v2: request and success-response payloads are carried over text data streams
     * instead of inline packets, lifting the 15 KB payload limit.
     */
    DATA_STREAM_RPC(1),
}

class ServerInfo(
    val edition: Edition,
    val version: Semver?,
) {
    enum class Edition {
        STANDARD,
        CLOUD,
        UNKNOWN
        ;

        companion object {
            fun fromProto(proto: LivekitModels.ServerInfo.Edition): Edition {
                return when (proto) {
                    LivekitModels.ServerInfo.Edition.Standard -> STANDARD
                    LivekitModels.ServerInfo.Edition.Cloud -> CLOUD
                    LivekitModels.ServerInfo.Edition.UNRECOGNIZED -> UNKNOWN
                }
            }
        }
    }
}
