package com.github.TempTalkOrg.audio_pipeline

import android.content.Context

/**
 * Pure PCM-in / PCM-out processing core.
 *
 * Single-output mode (legacy): one chain `[denoise?] -> [soundtouch?]`,
 * `process()` returns a FloatArray.
 *
 * Multi-output mode: a single shared denoise context fans out into one or
 * more taps, each with its own optional SoundTouch chain. Denoise inference
 * runs at most once per chunk regardless of how many taps consume it.
 * `processTaps()` returns a `Map<tapId, FloatArray>` keyed by the same ids
 * the caller passed to `taps`.
 *
 * Each instance owns its own RNNoise / DeepFilterNet / SoundTouch native
 * contexts, input ring buffer and warmup state. Calling [reset] / [flush]
 * / [release] on this instance NEVER touches any other instance — including
 * any [AudioPipelineProcessor] running in the same process for LiveKit.
 *
 * Threading: not thread-safe. Callers must externally serialise access.
 */
internal class AudioPipelineCore(
    context: Context,
    initialModule: AudioModule = AudioModule.RNNOISE,
    deepFilterConfig: DeepFilterConfig = DeepFilterConfig(),
    legacySoundTouchConfig: SoundTouchConfig = SoundTouchConfig(),
    legacyDenoiseEnabled: Boolean = true,
    taps: Map<String, PipelineTapConfig>? = null,
    // When `true`, run WebRTC APM (AGC2 adaptive digital + HPF) on the raw
    // mic signal BEFORE the denoise stage. This compensates for Android's
    // HAL ducking of parallel mic captures during VOICE_COMMUNICATION
    // calls, which would otherwise leave the signal so quiet that DFN
    // attenuates it to silence.
    private val agcEnabled: Boolean = true,
) {
    companion object {
        private const val TAG = "AudioPipelineCore"
        private const val MODEL_ASSET_NAME = "audio_pipeline/deepfilter_model.dfn"
        private const val RNNOISE_FRAME_SIZE = 480
        private const val RING_CAPACITY_FRAMES = 128
        // WebRTC APM operates on fixed 10 ms chunks. Our default frame
        // length (RNNoise + the 48 kHz DFN model) is also 480 samples =
        // 10 ms, so the APM frame divides our pipeline frame evenly.
        private const val APM_SAMPLE_RATE_HZ = 48_000
        private const val APM_NUM_CHANNELS = 1
        private const val APM_FRAME_LENGTH = APM_SAMPLE_RATE_HZ / 100  // 480
        const val LEGACY_TAP_ID = "default"
    }

    /** Per-tap mutable state owned by the core. */
    private class TapState(
        val id: String,
        var denoise: Boolean,
        var soundTouchConfig: SoundTouchConfig?,
        var stContext: Long,
    )

    // Pre-read the DeepFilterNet model bytes so create() never touches I/O on
    // the audio thread. Shared across denoise backend switches and all taps.
    private val modelBytes: ByteArray =
        context.assets.open(MODEL_ASSET_NAME).use { it.readBytes() }

    private var rnnoiseContext: Long = 0
    private var dfContext: Long = 0
    // Native WebRTC AudioProcessing handle. 0 means "not allocated" (either
    // disabled by config, allocation failed, or the current frame length
    // can't be processed by APM — see [maybeRunApmInPlace]).
    private var apmContext: Long = 0
    // The frame length APM was created for. APM is fixed at 480 samples
    // (10 ms @ 48 kHz mono); if the active denoise module ever requests a
    // different frame length we just skip APM rather than create multiple
    // APM instances or chunk the frame.
    private val apmFrameLength: Int = APM_FRAME_LENGTH

    private var activeModule: AudioModule = initialModule
    private var currentDfConfig: DeepFilterConfig = deepFilterConfig

    private val tapList: MutableList<TapState>
    private val multiTap: Boolean

    private var dfFrameLength: Int = 0
    private var dfInputBuffer: FloatArray = FloatArray(0)
    private var dfOutputBuffer: FloatArray = FloatArray(0)

    private var frameLength: Int = RNNOISE_FRAME_SIZE
    private var inputRing: FloatRingBuffer = FloatRingBuffer(RNNOISE_FRAME_SIZE * RING_CAPACITY_FRAMES)
    /** One mic frame pulled from the ring buffer per iteration. */
    private var rawFrameScratch: FloatArray = FloatArray(RNNOISE_FRAME_SIZE)
    /** Shared denoised frame, populated on demand inside each process loop. */
    private var denoisedFrameScratch: FloatArray = FloatArray(RNNOISE_FRAME_SIZE)
    /** Per-tap mutable scratch (SoundTouch processes in place). */
    private var tapFrameScratch: FloatArray = FloatArray(RNNOISE_FRAME_SIZE)

    private var released = false

    init {
        // Resolve the tap list. Multi-tap mode is keyed on the presence of
        // `taps`; legacy mode collapses the old `denoiseEnabled` +
        // `soundTouchConfig` into a single implicit "default" tap so the
        // rest of the core only has to reason about one shape.
        if (taps != null) {
            require(taps.isNotEmpty()) { "AudioPipelineCore: taps must not be empty" }
            multiTap = true
            tapList = taps.entries.map { (id, config) ->
                TapState(
                    id = id,
                    denoise = config.denoise,
                    soundTouchConfig = config.soundTouch?.takeIf { it.enabled },
                    stContext = 0,
                )
            }.toMutableList()
        } else {
            multiTap = false
            tapList = mutableListOf(
                TapState(
                    id = LEGACY_TAP_ID,
                    denoise = legacyDenoiseEnabled,
                    soundTouchConfig = legacySoundTouchConfig.takeIf { it.enabled },
                    stContext = 0,
                ),
            )
        }

        // Transactional native-context allocation: if any of the ensure* calls
        // below throws (OOM, asset corruption, DFN model deserialisation
        // failure, …), roll back every JNI handle we already allocated so
        // the half-constructed instance — which the caller will never see
        // and the JVM is about to GC — does not leak the ~16 MB DFN model
        // context plus any per-tap SoundTouch contexts that already succeeded.
        try {
            val anyDenoise = tapList.any { it.denoise }
            if (anyDenoise) {
                if (initialModule == AudioModule.DEEP_FILTER_NET) {
                    ensureDeepFilter()
                    if (dfFrameLength > 0) switchFrameLength(dfFrameLength)
                } else {
                    ensureRnnoise()
                }
            }

            // Init per-tap SoundTouch instances.
            for (tap in tapList) {
                ensureSoundTouchForTap(tap)
            }

            // Init WebRTC APM once (shared across all taps). Failure is
            // non-fatal: the pipeline still works without AGC, just with
            // worse low-volume behaviour. We log via android.util.Log so
            // operators can correlate "no AGC" with audio quality reports.
            if (agcEnabled) {
                apmContext = OfflineAudioPipelineNative.apmCreate(
                    sampleRateHz = APM_SAMPLE_RATE_HZ,
                    numChannels = APM_NUM_CHANNELS,
                    agcEnabled = true,
                    hpfEnabled = true,
                )
                if (apmContext == 0L) {
                    android.util.Log.w(
                        TAG,
                        "WebRTC APM allocation failed; continuing without AGC/HPF",
                    )
                }
            }
        } catch (t: Throwable) {
            destroyAllNativeContexts()
            throw t
        }
    }

    fun getActiveModule(): AudioModule = activeModule
    fun getFrameLength(): Int = frameLength
    fun isMultiTap(): Boolean = multiTap
    fun getTapIds(): List<String> = tapList.map { it.id }

    /** True if any tap consumes denoise. */
    fun isDenoiseEnabled(): Boolean = tapList.any { it.denoise }

    /** True if any tap runs SoundTouch. */
    fun isVoiceChangerEnabled(): Boolean =
        tapList.any { it.soundTouchConfig?.enabled == true }

    // ── Single-tap legacy API ──────────────────────────────────────────

    /**
     * Single-output process. Throws in multi-tap mode — use [processTaps].
     *
     * Returns a freshly allocated FloatArray whose length is always a multiple
     * of [frameLength]. Sub-frame residuals are buffered internally and
     * emitted on the next call (or by [flush]).
     */
    fun process(input: FloatArray): FloatArray {
        assertSingleTap("process")
        return processTaps(input).getValue(LEGACY_TAP_ID)
    }

    /** Single-output flush. Throws in multi-tap mode — use [flushTaps]. */
    fun flush(): FloatArray {
        assertSingleTap("flush")
        return flushTaps().getValue(LEGACY_TAP_ID)
    }

    // ── Multi-tap API ──────────────────────────────────────────────────

    /**
     * Multi-output process. Returns one FloatArray per tap, keyed by the id
     * the caller registered. In legacy single-tap mode this returns a
     * one-entry map keyed by [LEGACY_TAP_ID].
     *
     * Denoise inference runs at most once per chunk regardless of how many
     * taps consume the denoised PCM. Each tap with SoundTouch has its own
     * stateful pitch shifter.
     */
    fun processTaps(input: FloatArray): Map<String, FloatArray> {
        assertAlive()
        if (input.isEmpty()) return makeEmptyTapOutputs(0)

        ensureRingCapacity(input.size)
        inputRing.push(input)

        val frameLen = frameLength
        if (frameLen == 0 || inputRing.framesAvailable < frameLen) {
            return makeEmptyTapOutputs(0)
        }

        val frameCount = inputRing.framesAvailable / frameLen
        val outputs = makeEmptyTapOutputs(frameCount * frameLen)

        for (f in 0 until frameCount) {
            inputRing.pull(rawFrameScratch)
            runFrameIntoTaps(f * frameLen, outputs)
        }

        return outputs
    }

    /**
     * Multi-output flush. Per-tap analog of [flush]; same caveats.
     *
     * Pulls whatever the input ring buffer has accumulated since the last
     * frame-aligned [processTaps] call (typically < 1 backend frame =
     * ≤ 10 ms), pads it to a full frame with zeros, runs it through every
     * tap, and returns only the slice of samples that correspond to actual
     * mic input. The zero padding never appears in returned arrays.
     *
     * Voice changer caveat: each SoundTouch instance keeps an internal
     * ~40–50 ms FIFO (SETTING_SEQUENCE_MS=40, OVERLAP_MS=8) that always
     * lags its input by that algorithmic delay. Sample counts still match
     * exactly; only the "pitched tail of the recording" information is
     * lost for taps that use SoundTouch.
     */
    fun flushTaps(): Map<String, FloatArray> {
        assertAlive()
        val remaining = inputRing.framesAvailable
        val frameLen = frameLength
        if (remaining == 0 || frameLen == 0) return makeEmptyTapOutputs(0)

        // Pull partial frame into first `remaining` slots; trailing zero.
        rawFrameScratch.fill(0f)
        val tail = FloatArray(remaining)
        inputRing.pull(tail)
        System.arraycopy(tail, 0, rawFrameScratch, 0, remaining)

        val padded = makeEmptyTapOutputs(frameLen)
        runFrameIntoTaps(0, padded)

        // Trim each tap output back to the real sample count.
        val trimmed = LinkedHashMap<String, FloatArray>(tapList.size)
        for (tap in tapList) {
            trimmed[tap.id] = padded.getValue(tap.id).copyOf(remaining)
        }
        return trimmed
    }

    // ── Lifecycle / configuration ─────────────────────────────────────

    /** Clear internal buffers and reset SoundTouch warmup state for every tap. */
    fun reset() {
        assertAlive()
        inputRing.clear()
        // RNNoise / DeepFilterNet are kept because their per-frame behaviour
        // does not depend on stream boundaries; SoundTouch's FIFO is rebuilt.
        for (tap in tapList) {
            if (tap.stContext != 0L && tap.soundTouchConfig != null) {
                OfflineAudioPipelineNative.stDestroy(tap.stContext)
                tap.stContext = 0L
                ensureSoundTouchForTap(tap)
            }
        }
    }

    fun release() {
        if (released) return
        released = true
        destroyAllNativeContexts()
    }

    /**
     * Destroy every native context this instance currently holds, in any order.
     * Idempotent (each handle is checked against 0/0L before destroy) so it's
     * safe to call from both [release] (normal lifecycle) and the constructor
     * rollback path (partial-init failure) without double-freeing.
     */
    private fun destroyAllNativeContexts() {
        if (rnnoiseContext != 0L) {
            OfflineAudioPipelineNative.rnnoiseDestroy(rnnoiseContext)
            rnnoiseContext = 0
        }
        if (dfContext != 0L) {
            OfflineAudioPipelineNative.dfDestroy(dfContext)
            dfContext = 0
            dfFrameLength = 0
            dfInputBuffer = FloatArray(0)
            dfOutputBuffer = FloatArray(0)
        }
        for (tap in tapList) {
            if (tap.stContext != 0L) {
                OfflineAudioPipelineNative.stDestroy(tap.stContext)
                tap.stContext = 0L
            }
        }
        if (apmContext != 0L) {
            OfflineAudioPipelineNative.apmDestroy(apmContext)
            apmContext = 0
        }
    }

    fun setModule(module: AudioModule) {
        assertAlive()
        if (module == activeModule) return
        val anyDenoise = tapList.any { it.denoise }
        if (anyDenoise) {
            when (module) {
                AudioModule.DEEP_FILTER_NET -> ensureDeepFilter()
                AudioModule.RNNOISE -> ensureRnnoise()
            }
        }
        activeModule = module
        val nextFrameLength = when (module) {
            AudioModule.DEEP_FILTER_NET -> if (dfFrameLength > 0) dfFrameLength else RNNOISE_FRAME_SIZE
            AudioModule.RNNOISE -> RNNOISE_FRAME_SIZE
        }
        if (nextFrameLength != frameLength) {
            switchFrameLength(nextFrameLength)
            // Rebuild each tap's SoundTouch to match the new frame length.
            for (tap in tapList) {
                if (tap.stContext != 0L && tap.soundTouchConfig != null) {
                    OfflineAudioPipelineNative.stDestroy(tap.stContext)
                    tap.stContext = 0L
                    ensureSoundTouchForTap(tap)
                }
            }
        }
    }

    /**
     * Toggle denoise on/off in legacy single-tap mode. Throws in multi-tap
     * mode (where each tap's denoise flag was fixed at construction time).
     */
    fun setDenoiseEnabled(enabled: Boolean) {
        assertAlive()
        assertSingleTap("setDenoiseEnabled")
        tapList[0].denoise = enabled
    }

    /**
     * Legacy single-tap SoundTouch config setter. Throws in multi-tap mode.
     */
    fun setSoundTouchConfig(config: SoundTouchConfig) {
        assertAlive()
        assertSingleTap("setSoundTouchConfig")
        val tap = tapList[0]
        if (config.enabled) {
            tap.soundTouchConfig = config
            ensureSoundTouchForTap(tap)
            if (tap.stContext != 0L) {
                OfflineAudioPipelineNative.stSetPitchSemiTones(tap.stContext, config.pitchSemiTones)
            }
        } else {
            tap.soundTouchConfig = null
            if (tap.stContext != 0L) {
                OfflineAudioPipelineNative.stDestroy(tap.stContext)
                tap.stContext = 0L
            }
        }
    }

    fun updateDeepFilterConfig(config: DeepFilterConfig) {
        assertAlive()
        currentDfConfig = config
        if (dfContext != 0L) {
            OfflineAudioPipelineNative.dfSetAttenLim(dfContext, config.attenLimDb)
            OfflineAudioPipelineNative.dfSetPostFilterBeta(dfContext, config.postFilterBeta)
        }
    }

    // ── internals ────────────────────────────────────────────────────

    /**
     * Pull one frame through every tap. Assumes [rawFrameScratch] is already
     * populated; writes into `outputs[tapId]` at offset `writeOffset`. Shared
     * denoise inference runs at most once per frame regardless of tap count.
     */
    private fun runFrameIntoTaps(writeOffset: Int, outputs: Map<String, FloatArray>) {
        val frameLen = frameLength

        // Stage 0: APM pre-processing (HPF + AGC2 adaptive digital), in
        // place on the raw mic frame. Runs before denoise so the AGC sees
        // the untouched envelope of the mic signal — denoise would
        // otherwise lower the level the AGC chases. Skipped when the
        // active denoise module uses a frame length other than 10 ms.
        maybeRunApmInPlace(frameLen)

        var denoisedReady = false

        for (tap in tapList) {
            val baseFrame: FloatArray = if (tap.denoise) {
                val moduleAvailable = when (activeModule) {
                    AudioModule.RNNOISE -> rnnoiseContext != 0L
                    AudioModule.DEEP_FILTER_NET -> dfContext != 0L && dfFrameLength == frameLen
                }
                if (moduleAvailable) {
                    if (!denoisedReady) {
                        when (activeModule) {
                            AudioModule.RNNOISE -> {
                                System.arraycopy(rawFrameScratch, 0, denoisedFrameScratch, 0, frameLen)
                                OfflineAudioPipelineNative.rnnoiseProcessFrame(rnnoiseContext, denoisedFrameScratch)
                            }
                            AudioModule.DEEP_FILTER_NET -> {
                                System.arraycopy(rawFrameScratch, 0, dfInputBuffer, 0, frameLen)
                                OfflineAudioPipelineNative.dfProcessFrame(dfContext, dfInputBuffer, dfOutputBuffer)
                                System.arraycopy(dfOutputBuffer, 0, denoisedFrameScratch, 0, frameLen)
                            }
                        }
                        denoisedReady = true
                    }
                    denoisedFrameScratch
                } else {
                    // Tap requested denoise but module isn't available;
                    // fall back to raw rather than producing zeros.
                    rawFrameScratch
                }
            } else {
                rawFrameScratch
            }

            // SoundTouch processes in place — copy into the per-tap scratch.
            System.arraycopy(baseFrame, 0, tapFrameScratch, 0, frameLen)
            if (tap.stContext != 0L && tap.soundTouchConfig?.enabled == true) {
                OfflineAudioPipelineNative.stProcessFrame(tap.stContext, tapFrameScratch)
            }
            System.arraycopy(tapFrameScratch, 0, outputs.getValue(tap.id), writeOffset, frameLen)
        }
    }

    /**
     * Pre-process [rawFrameScratch] through WebRTC APM in place when both
     *   1) the APM context was allocated successfully, and
     *   2) the current pipeline frame length matches APM's 10 ms chunk.
     *
     * If APM returns a non-zero status the buffer is left in whatever
     * state the bridge returned (APM only mutates on success), so callers
     * still get usable PCM. We log non-zero results once per occurrence to
     * keep the audio thread quiet.
     */
    private fun maybeRunApmInPlace(frameLen: Int) {
        if (apmContext == 0L) return
        if (frameLen != apmFrameLength) return
        val rc = OfflineAudioPipelineNative.apmProcessFrame(apmContext, rawFrameScratch)
        if (rc != 0) {
            android.util.Log.w(TAG, "APM ProcessStream returned $rc (frame skipped)")
        }
    }

    private fun makeEmptyTapOutputs(perTapLength: Int): Map<String, FloatArray> {
        val out = LinkedHashMap<String, FloatArray>(tapList.size)
        for (tap in tapList) {
            out[tap.id] = FloatArray(perTapLength)
        }
        return out
    }

    private fun ensureRnnoise() {
        if (rnnoiseContext != 0L) return
        rnnoiseContext = OfflineAudioPipelineNative.rnnoiseCreate()
    }

    private fun ensureDeepFilter() {
        if (dfContext != 0L) return
        val cfg = currentDfConfig
        dfContext = OfflineAudioPipelineNative.dfCreateFromBytes(
            modelBytes,
            cfg.attenLimDb,
            cfg.minDbThresh,
            cfg.maxDbErbThresh,
            cfg.maxDbDfThresh,
        )
        if (dfContext != 0L) {
            dfFrameLength = OfflineAudioPipelineNative.dfGetFrameLength(dfContext)
            if (dfFrameLength > 0) {
                dfInputBuffer = FloatArray(dfFrameLength)
                dfOutputBuffer = FloatArray(dfFrameLength)
            }
            OfflineAudioPipelineNative.dfSetAttenLim(dfContext, cfg.attenLimDb)
            OfflineAudioPipelineNative.dfSetPostFilterBeta(dfContext, cfg.postFilterBeta)
        }
    }

    private fun ensureSoundTouchForTap(tap: TapState) {
        if (tap.stContext != 0L) return
        val config = tap.soundTouchConfig ?: return
        if (!config.enabled) return
        tap.stContext = OfflineAudioPipelineNative.stCreate()
        if (tap.stContext != 0L) {
            OfflineAudioPipelineNative.stSetPitchSemiTones(tap.stContext, config.pitchSemiTones)
        }
    }

    private fun switchFrameLength(newLength: Int) {
        if (newLength <= 0 || newLength == frameLength) return

        // Carry over any leftover residual; it remains valid PCM at 48 kHz.
        val carryover = if (inputRing.framesAvailable > 0) {
            FloatArray(inputRing.framesAvailable).also { inputRing.pull(it) }
        } else null

        frameLength = newLength
        inputRing = FloatRingBuffer(newLength * RING_CAPACITY_FRAMES)
        rawFrameScratch = FloatArray(newLength)
        denoisedFrameScratch = FloatArray(newLength)
        tapFrameScratch = FloatArray(newLength)
        carryover?.let { inputRing.push(it) }
    }

    private fun ensureRingCapacity(incoming: Int) {
        val needed = inputRing.framesAvailable + incoming
        if (needed <= inputRing.capacity) return
        val newCap = maxOf(inputRing.capacity * 2, needed + frameLength)
        val carryover = if (inputRing.framesAvailable > 0) {
            FloatArray(inputRing.framesAvailable).also { inputRing.pull(it) }
        } else null
        inputRing = FloatRingBuffer(newCap)
        carryover?.let { inputRing.push(it) }
    }

    private fun assertAlive() {
        if (released) {
            throw IllegalStateException("AudioPipelineCore: instance has been released")
        }
    }

    private fun assertSingleTap(method: String) {
        if (multiTap) {
            throw IllegalStateException(
                "AudioPipelineCore.$method() is not valid on a multi-tap pipeline. " +
                    "Use ${method}Taps() (or the matching method on OfflineAudioPipeline) instead.",
            )
        }
    }
}
