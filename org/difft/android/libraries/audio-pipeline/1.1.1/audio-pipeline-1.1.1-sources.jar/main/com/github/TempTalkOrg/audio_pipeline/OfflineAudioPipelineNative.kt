package com.github.TempTalkOrg.audio_pipeline

import android.util.Log

/**
 * Static JNI bindings used by [OfflineAudioPipeline] / [AudioPipelineCore].
 *
 * Kept separate from [AudioPipelineProcessor]'s native methods so that:
 *
 * 1. JNI symbol names stay unique per Kotlin class (Java/Kotlin native methods
 *    are bound by class FQN), and
 * 2. The realtime LiveKit adapter ([AudioPipelineProcessor]) can keep its
 *    existing public surface without becoming a singleton store for native
 *    pointers.
 *
 * All `process*` methods operate in **normalized [-1, 1] float32 PCM** at
 * 48 kHz mono, matching the natural format produced by [android.media.AudioRecord]
 * with `ENCODING_PCM_FLOAT`. Scaling to/from the int16 range expected by
 * RNNoise / SoundTouch is handled inside the JNI layer.
 *
 * Each `*Create` returns a `Long` handle that the caller owns and must release
 * via the matching `*Destroy` call. Handles are independent across instances:
 * calling `*Destroy` on one handle never touches another.
 */
internal object OfflineAudioPipelineNative {
    private const val TAG = "OfflineAudioPipelineNative"

    init {
        try {
            System.loadLibrary("audio_pipeline")
        } catch (e: UnsatisfiedLinkError) {
            Log.e(TAG, "Error loading library: ${e.message}")
        }
    }

    /* ── RNNoise ─────────────────────────────────────────────────────── */

    @JvmStatic external fun rnnoiseCreate(): Long
    @JvmStatic external fun rnnoiseDestroy(st: Long)

    /**
     * In-place process one RNNoise frame. The array must hold exactly
     * RNNOISE_FRAME (480) normalized float32 samples; values are mutated in
     * place and the VAD score is returned.
     */
    @JvmStatic external fun rnnoiseProcessFrame(st: Long, inOut: FloatArray): Float

    /* ── DeepFilterNet ───────────────────────────────────────────────── */

    @JvmStatic external fun dfCreateFromBytes(
        modelBytes: ByteArray,
        attenLimDb: Float,
        minDbThresh: Float,
        maxDbErbThresh: Float,
        maxDbDfThresh: Float
    ): Long

    @JvmStatic external fun dfDestroy(st: Long)
    @JvmStatic external fun dfGetFrameLength(st: Long): Int

    /**
     * Process one DeepFilterNet frame. `input` and `output` must both have
     * length equal to `dfGetFrameLength(st)` and contain normalized float32
     * samples in [-1, 1]. Returns the LSNR estimate of this frame.
     */
    @JvmStatic external fun dfProcessFrame(st: Long, input: FloatArray, output: FloatArray): Float

    @JvmStatic external fun dfSetAttenLim(st: Long, limDb: Float)
    @JvmStatic external fun dfSetPostFilterBeta(st: Long, beta: Float)

    /* ── SoundTouch ──────────────────────────────────────────────────── */

    @JvmStatic external fun stCreate(): Long
    @JvmStatic external fun stDestroy(st: Long)
    @JvmStatic external fun stSetPitchSemiTones(st: Long, semitones: Float)

    /**
     * In-place process one SoundTouch frame of normalized float32 samples.
     * Returns true when output was written; false during the FIFO warmup
     * window, in which case the samples are left unchanged.
     */
    @JvmStatic external fun stProcessFrame(st: Long, inOut: FloatArray): Boolean

    /* ── WebRTC APM (AGC2 adaptive digital + High-pass filter) ──────── */

    /**
     * Create a WebRTC AudioProcessing instance configured as a pre-processor
     * on the capture stream. Returns 0L on failure (caller should treat as
     * "APM not available" and fall back to the raw signal).
     *
     * Frame contract: exactly `sampleRateHz / 100` samples per channel per
     * [apmProcessFrame] call (i.e. 480 samples at 48 kHz mono).
     */
    @JvmStatic external fun apmCreate(
        sampleRateHz: Int,
        numChannels: Int,
        agcEnabled: Boolean,
        hpfEnabled: Boolean,
    ): Long

    @JvmStatic external fun apmDestroy(handle: Long)

    /**
     * In-place process one 10 ms frame. Returns 0 on success, negative on
     * bridge-side validation failure (see webrtc_apm_bridge.cpp for codes),
     * or a positive [AudioProcessing::Error] value when APM itself rejects
     * the call. The caller should log non-zero results but should still
     * pass the (possibly unmodified) buffer downstream — APM only mutates
     * the buffer on success.
     */
    @JvmStatic external fun apmProcessFrame(handle: Long, inOut: FloatArray): Int
}
