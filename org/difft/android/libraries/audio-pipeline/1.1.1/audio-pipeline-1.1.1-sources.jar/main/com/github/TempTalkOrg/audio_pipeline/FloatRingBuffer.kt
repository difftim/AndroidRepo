package com.github.TempTalkOrg.audio_pipeline

/**
 * Simple bounded mono float32 ring buffer. Matches the contract of the JS
 * `MonoRingBuffer` used by [AudioPipelineCore] / web worklet so the two
 * platforms behave identically.
 *
 * Not thread-safe — callers must externally serialise push/pull.
 */
internal class FloatRingBuffer(capacity: Int) {
    private val data = FloatArray(capacity)
    private var readIndex = 0
    private var writeIndex = 0
    private var available = 0

    val framesAvailable: Int get() = available
    val capacity: Int get() = data.size

    fun push(input: FloatArray, count: Int = input.size) {
        if (count == 0) return
        val cap = data.size
        val tail = cap - writeIndex
        if (count <= tail) {
            System.arraycopy(input, 0, data, writeIndex, count)
        } else {
            System.arraycopy(input, 0, data, writeIndex, tail)
            System.arraycopy(input, tail, data, 0, count - tail)
        }
        writeIndex = (writeIndex + count) % cap
        available = (available + count).coerceAtMost(cap)
    }

    /**
     * Pull exactly `target.size` samples into `target`. Returns true when the
     * read succeeded; returns false and zero-fills `target` when fewer samples
     * are available.
     */
    fun pull(target: FloatArray): Boolean {
        val len = target.size
        if (available < len) {
            target.fill(0f)
            return false
        }
        val cap = data.size
        val tail = cap - readIndex
        if (len <= tail) {
            System.arraycopy(data, readIndex, target, 0, len)
        } else {
            System.arraycopy(data, readIndex, target, 0, tail)
            System.arraycopy(data, 0, target, tail, len - tail)
        }
        readIndex = (readIndex + len) % cap
        available -= len
        return true
    }

    fun clear() {
        readIndex = 0
        writeIndex = 0
        available = 0
        data.fill(0f)
    }
}
