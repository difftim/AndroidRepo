package com.github.TempTalkOrg.audio_pipeline

import android.content.Context

/**
 * PCM-in / PCM-out audio pipeline for **offline / non-LiveKit** scenarios
 * (voice messages, file processing, local PCM streams).
 *
 * - Input / output: 48 kHz mono **normalized float32** PCM ([-1.0, 1.0]),
 *   matching `AudioRecord` with `ENCODING_PCM_FLOAT`.
 * - Threading: not thread-safe; callers must externally serialise access
 *   from the recording / encoding thread.
 * - Instance isolation: each `OfflineAudioPipeline` owns its own RNNoise /
 *   DeepFilterNet / SoundTouch native contexts; [reset] / [flush] / [release]
 *   on this instance never affect any other instance (including any
 *   [AudioPipelineProcessor] running in the same process for LiveKit).
 *
 * ## Single-tap (legacy) usage:
 *
 * ```kotlin
 * val pipeline = OfflineAudioPipeline(
 *     context = applicationContext,
 *     initialModule = AudioModule.DEEP_FILTER_NET,
 *     soundTouchConfig = SoundTouchConfig(enabled = true, pitchSemiTones = 4f),
 * )
 *
 * while (recording) {
 *     val pcm: FloatArray = readPcmChunkFromAudioRecord()
 *     val processed = pipeline.process(pcm)
 *     encoder.encode(processed)
 * }
 *
 * val tail = pipeline.flush()
 * if (tail.isNotEmpty()) encoder.encode(tail)
 * encoder.signalEndOfStream()
 * pipeline.release()
 * ```
 *
 * ## Multi-tap usage (mirrors the chative-desktop dual-candidate flow):
 *
 * ```kotlin
 * val pipeline = OfflineAudioPipeline(
 *     context = applicationContext,
 *     initialModule = AudioModule.DEEP_FILTER_NET,
 *     taps = mapOf(
 *         "denoised"          to PipelineTapConfig(denoise = true),
 *         "denoised+higher"   to PipelineTapConfig(
 *             denoise = true,
 *             soundTouch = SoundTouchConfig.PRESETS["goddess"],
 *         ),
 *     ),
 * )
 *
 * while (recording) {
 *     val pcm = readPcmChunkFromAudioRecord()
 *     val outs = pipeline.processTaps(pcm) // Map<String, FloatArray>
 *     outs["denoised"]?.takeIf { it.isNotEmpty() }?.let { denoisedEncoder.encode(it) }
 *     outs["denoised+higher"]?.takeIf { it.isNotEmpty() }?.let { processedEncoder.encode(it) }
 * }
 *
 * val tails = pipeline.flushTaps()
 * tails["denoised"]?.takeIf { it.isNotEmpty() }?.let { denoisedEncoder.encode(it) }
 * tails["denoised+higher"]?.takeIf { it.isNotEmpty() }?.let { processedEncoder.encode(it) }
 * pipeline.release()
 * ```
 *
 * Denoise inference runs once per chunk regardless of how many taps consume
 * the denoised PCM. Each tap with `soundTouch` gets its own pitch shifter.
 */
class OfflineAudioPipeline private constructor(
    private val core: AudioPipelineCore,
) {
    /**
     * Single-tap (legacy) constructor. Builds an `OfflineAudioPipeline` with
     * one implicit "default" tap whose denoise + voice-changer config is
     * controlled by [denoiseEnabled] and [soundTouchConfig].
     *
     * Use the multi-tap constructor (`taps` parameter) when you need
     * multiple parallel candidates with shared denoise.
     */
    constructor(
        context: Context,
        initialModule: AudioModule = AudioModule.RNNOISE,
        deepFilterConfig: DeepFilterConfig = DeepFilterConfig(),
        soundTouchConfig: SoundTouchConfig = SoundTouchConfig(),
        denoiseEnabled: Boolean = true,
        agcEnabled: Boolean = true,
    ) : this(
        AudioPipelineCore(
            context = context,
            initialModule = initialModule,
            deepFilterConfig = deepFilterConfig,
            legacySoundTouchConfig = soundTouchConfig,
            legacyDenoiseEnabled = denoiseEnabled,
            taps = null,
            agcEnabled = agcEnabled,
        ),
    )

    /**
     * Multi-tap constructor. One shared denoise context fans out into N
     * parallel taps, each with its own optional SoundTouch chain.
     *
     * The order of [taps] is preserved (iteration order matches the input
     * map's iteration order, so use a `LinkedHashMap` if you need
     * deterministic ordering).
     */
    constructor(
        context: Context,
        taps: Map<String, PipelineTapConfig>,
        initialModule: AudioModule = AudioModule.RNNOISE,
        deepFilterConfig: DeepFilterConfig = DeepFilterConfig(),
        agcEnabled: Boolean = true,
    ) : this(
        AudioPipelineCore(
            context = context,
            initialModule = initialModule,
            deepFilterConfig = deepFilterConfig,
            taps = taps,
            agcEnabled = agcEnabled,
        ),
    )

    /**
     * Construction is synchronous but touches disk (reads the DeepFilterNet
     * model from `assets/audio_pipeline/deepfilter_model.dfn`, ~16 MB) and
     * runs `df_create_default` to deserialise it. **Always construct off the
     * UI thread**:
     *
     * ```kotlin
     * val pipeline = withContext(Dispatchers.IO) {
     *     OfflineAudioPipeline(applicationContext, taps = recipes)
     * }
     * ```
     *
     * (We deliberately don't ship a suspend factory in the SDK to avoid
     * pulling `kotlinx-coroutines-android` into the SDK's compile classpath
     * for that one method — every consumer of the offline API already has
     * coroutines available.)
     */

    /** Currently active denoise backend. */
    val activeModule: AudioModule get() = core.getActiveModule()

    /** Frame length (samples) of the currently active denoise backend. */
    val frameLength: Int get() = core.getFrameLength()

    /** True when constructed with `taps`. `process()` / `flush()` throw in this mode. */
    val isMultiTap: Boolean get() = core.isMultiTap()

    /** Tap ids in the order they were declared (single-tap mode = ["default"]). */
    val tapIds: List<String> get() = core.getTapIds()

    /** True if any tap consumes denoise. */
    val denoiseEnabled: Boolean get() = core.isDenoiseEnabled()

    /** True if any tap runs SoundTouch. */
    val voiceChangerEnabled: Boolean get() = core.isVoiceChangerEnabled()

    // ── Single-tap legacy API ──────────────────────────────────────────

    /**
     * Single-output process. Throws in multi-tap mode — use [processTaps].
     *
     * Returns a freshly allocated FloatArray whose length is always a
     * multiple of [frameLength]. Sub-frame residuals are buffered internally
     * and emitted on the next call (or by [flush]).
     */
    fun process(input: FloatArray): FloatArray = core.process(input)

    /**
     * Single-output flush. Throws in multi-tap mode — use [flushTaps].
     *
     * Returns the sub-frame remainder from the input ring buffer
     * (zero-padded for processing, then trimmed back to the real sample
     * count) so total output sample count matches total input sample count.
     *
     * Voice changer caveat: SoundTouch's ~50 ms algorithmic FIFO is not
     * drained at flush time — see [AudioPipelineCore.flush] for the full
     * explanation. Sample counts still align; only the "processed tail"
     * information of the last ~50 ms of recording is lost.
     */
    fun flush(): FloatArray = core.flush()

    // ── Multi-tap API ──────────────────────────────────────────────────

    /**
     * Multi-output process. Returns one FloatArray per tap, keyed by the id
     * the caller registered. In legacy single-tap mode this returns a
     * one-entry map keyed by `"default"`.
     *
     * Denoise inference runs at most once per chunk regardless of how many
     * taps consume the denoised PCM. Each tap with SoundTouch has its own
     * stateful pitch shifter.
     */
    fun processTaps(input: FloatArray): Map<String, FloatArray> = core.processTaps(input)

    /**
     * Multi-output flush. Per-tap analog of [flush]; same caveats.
     */
    fun flushTaps(): Map<String, FloatArray> = core.flushTaps()

    // ── Lifecycle / configuration ─────────────────────────────────────

    /** Clear internal state. Instance stays usable. */
    fun reset() = core.reset()

    /** Release all native resources. Instance becomes unusable. */
    fun release() = core.release()

    fun setModule(module: AudioModule) = core.setModule(module)

    /** Legacy single-tap only. Throws in multi-tap mode. */
    fun setDenoiseEnabled(enabled: Boolean) = core.setDenoiseEnabled(enabled)

    /** Legacy single-tap only. Throws in multi-tap mode. */
    fun setSoundTouchConfig(config: SoundTouchConfig) = core.setSoundTouchConfig(config)

    /**
     * Legacy single-tap convenience: apply a named preset
     * (loli / uncle / goddess / monster / original).
     */
    fun setSoundTouchPreset(preset: String) {
        val config = SoundTouchConfig.PRESETS[preset]
            ?: SoundTouchConfig(enabled = true, pitchSemiTones = 0f)
        setSoundTouchConfig(config)
    }

    fun updateDeepFilterConfig(config: DeepFilterConfig) = core.updateDeepFilterConfig(config)
}
