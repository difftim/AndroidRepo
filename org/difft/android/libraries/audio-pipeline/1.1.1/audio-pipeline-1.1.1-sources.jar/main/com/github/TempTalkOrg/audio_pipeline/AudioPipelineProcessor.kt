package com.github.TempTalkOrg.audio_pipeline

import android.content.Context
import android.util.Log
import java.nio.ByteBuffer

enum class AudioModule(val id: String) {
    RNNOISE("rnnoise"),
    DEEP_FILTER_NET("deepfilternet")
}

data class DeepFilterConfig(
        val attenLimDb: Float = 100f,
        val postFilterBeta: Float = 0f,
        val minDbThresh: Float = -15f,
        val maxDbErbThresh: Float = 35f,
        val maxDbDfThresh: Float = 35f
)

data class SoundTouchConfig(
        val enabled: Boolean = false,
        val pitchSemiTones: Float = 0f,
) {
    companion object {
        /** Built-in voice presets — resolve to a config with [enabled]=true. */
        val PRESETS: Map<String, SoundTouchConfig> = mapOf(
                "loli"     to SoundTouchConfig(enabled = true,  pitchSemiTones =  12f),
                "uncle"    to SoundTouchConfig(enabled = true,  pitchSemiTones =  -4f),
                "goddess"  to SoundTouchConfig(enabled = true,  pitchSemiTones =   4f),
                "monster"  to SoundTouchConfig(enabled = true,  pitchSemiTones = -10f),
                "original" to SoundTouchConfig(enabled = false, pitchSemiTones =   0f),
        )
    }
}

/**
 * One parallel output of a multi-tap [OfflineAudioPipeline].
 *
 * Each tap is a small mixer recipe: it picks whether to take the shared
 * denoised frame or the raw mic frame, and optionally runs its own
 * SoundTouch voice-changer on top.
 *
 * Denoise inference is shared across every tap that sets `denoise = true`
 * (runs at most once per chunk regardless of tap count). SoundTouch is
 * per-tap because each preset needs its own stateful pitch shifter.
 *
 * Mirrors the JS SDK `PipelineTapConfig` shape so cross-platform
 * integration code stays familiar.
 */
data class PipelineTapConfig(
    /** Consume the shared denoised PCM. Defaults to false (raw passthrough). */
    val denoise: Boolean = false,
    /** Voice-changer chain applied after denoise/raw. `null` skips SoundTouch. */
    val soundTouch: SoundTouchConfig? = null,
)

class AudioPipelineProcessor(
        context: Context,
        private val debugLog: Boolean = false,
        private val vadLogs: Boolean = false,
        private val initialModule: AudioModule = AudioModule.RNNOISE,
        private val deepFilterConfig: DeepFilterConfig = DeepFilterConfig(),
        private val soundTouchConfig: SoundTouchConfig = SoundTouchConfig(),
) : io.livekit.android.audio.AudioProcessorInterface {

    companion object {
        private const val TAG = "AudioPipeline"
        private const val MODEL_ASSET_NAME = "audio_pipeline/deepfilter_model.dfn"

        init {
            try {
                System.loadLibrary("audio_pipeline")
            } catch (e: UnsatisfiedLinkError) {
                Log.e(TAG, "Error loading library: ${e.message}")
            }
        }

        private const val SUPPORT_SAMPLE_RATE_HZ = 48000
        private const val SUPPORT_NUM_CHANNELS = 1
        private const val RNNOISE_FRAME_SIZE = 480
    }

    // Pre-read at construction time so initializeAudioProcessing() has no I/O on the audio thread.
    private val modelBytes: ByteArray =
            context.assets.open(MODEL_ASSET_NAME).use { it.readBytes() }

    @Volatile private var rnnoiseContext: Long = 0

    @Volatile private var dfContext: Long = 0

    @Volatile private var stContext: Long = 0

    @Volatile private var activeModule: AudioModule = initialModule

    private var dfFrameLength: Int = 0
    private var dfOutputBuffer: ByteArray? = null
    @Volatile private var denoiseEnabled: Boolean = true
    private var currentDfConfig: DeepFilterConfig = deepFilterConfig
    private var currentStConfig: SoundTouchConfig = soundTouchConfig

    override fun getName(): String = "audio-pipeline"

    @Synchronized
    override fun initializeAudioProcessing(sampleRateHz: Int, numChannels: Int) {
        if (debugLog) {
            Log.d(
                    TAG,
                    "initializeAudioProcessing: sampleRateHz=$sampleRateHz, numChannels=$numChannels"
            )
        }

        if (SUPPORT_SAMPLE_RATE_HZ != sampleRateHz || SUPPORT_NUM_CHANNELS != numChannels) {
            return
        }

        initRnnoise()
        initDeepFilter()
        initSoundTouch()

        activeModule = initialModule
    }

    // Note: LiveKit calls processAudio() unconditionally; isEnabled() is a status indicator.
    // After the denoise/voice-changer split, this reflects the denoise enabled state only.
    @Synchronized override fun isEnabled(): Boolean = denoiseEnabled

    @Deprecated("Use setDenoiseEnabled()", ReplaceWith("setDenoiseEnabled(enable)"))
    @Synchronized
    fun setEnabled(enable: Boolean) {
        setDenoiseEnabled(enable)
    }

    @Synchronized
    fun setDenoiseEnabled(enabled: Boolean) {
        this.denoiseEnabled = enabled
        if (debugLog) Log.d(TAG, "setDenoiseEnabled: $enabled")
    }

    @Synchronized
    fun setVoiceChangerEnabled(enabled: Boolean) {
        setSoundTouchConfig(currentStConfig.copy(enabled = enabled))
    }

    @Synchronized
    fun setModule(module: AudioModule) {
        if (debugLog) {
            Log.d(TAG, "setModule: ${activeModule.id} -> ${module.id}")
        }
        activeModule = module
    }

    fun getActiveModule(): AudioModule = activeModule

    @Synchronized
    fun updateDeepFilterConfig(config: DeepFilterConfig) {
        currentDfConfig = config
        if (dfContext != 0L) {
            dfSetAttenLim(dfContext, config.attenLimDb)
            dfSetPostFilterBeta(dfContext, config.postFilterBeta)
        }
        if (debugLog) {
            Log.d(TAG, "updateDeepFilterConfig: $config")
        }
    }

    @Synchronized
    fun setSoundTouchConfig(config: SoundTouchConfig) {
        currentStConfig = config
        if (stContext != 0L) {
            stSetPitchSemiTones(stContext, config.pitchSemiTones)
        }
        if (debugLog) {
            Log.d(TAG, "setSoundTouchConfig: $config")
        }
    }

    /** Convenience: apply a named preset (loli / uncle / goddess / monster / original). */
    fun setSoundTouchPreset(preset: String) {
        val config = SoundTouchConfig.PRESETS[preset]
                ?: SoundTouchConfig(enabled = true, pitchSemiTones = 0f)
        setSoundTouchConfig(config)
    }

    @Synchronized
    override fun processAudio(numBands: Int, numFrames: Int, buffer: ByteBuffer) {
        if (denoiseEnabled) {
            when (activeModule) {
                AudioModule.RNNOISE -> processRnnoise(numBands, numFrames, buffer)
                AudioModule.DEEP_FILTER_NET -> processDeepFilter(numBands, numFrames, buffer)
            }
        }

        if (currentStConfig.enabled && stContext != 0L) {
            processSoundTouch(buffer)
        }
    }

    private fun processRnnoise(numBands: Int, numFrames: Int, buffer: ByteBuffer) {
        if (rnnoiseContext == 0L) return

        val byteArray = ByteArray(buffer.remaining())
        buffer.get(byteArray)

        val vad = rnnoiseProcessFrame(rnnoiseContext, byteArray)

        buffer.clear()
        buffer.put(byteArray)
        buffer.flip()

        if (debugLog && vadLogs) {
            Log.d(TAG, "processRnnoise: numBands=$numBands, numFrames=$numFrames, vad=$vad")
        }
    }

    private fun processSoundTouch(buffer: ByteBuffer) {
        if (stContext == 0L) return

        val byteArray = ByteArray(buffer.remaining())
        buffer.get(byteArray)

        stProcessFrame(stContext, byteArray)

        buffer.clear()
        buffer.put(byteArray)
        buffer.flip()
    }

    private fun processDeepFilter(numBands: Int, numFrames: Int, buffer: ByteBuffer) {
        if (dfContext == 0L) return

        val byteArray = ByteArray(buffer.remaining())
        buffer.get(byteArray)

        val outArray = dfOutputBuffer ?: return
        if (outArray.size != byteArray.size) return

        val lsnr = dfProcessFrame(dfContext, byteArray, outArray)

        buffer.clear()
        buffer.put(outArray)
        buffer.flip()

        if (debugLog && vadLogs) {
            Log.d(TAG, "processDeepFilter: numBands=$numBands, numFrames=$numFrames, lsnr=$lsnr")
        }
    }

    @Synchronized
    override fun resetAudioProcessing(newRate: Int) {
        if (debugLog) {
            Log.d(TAG, "resetAudioProcessing: newRate=$newRate")
        }

        releaseAllContexts()
        initRnnoise()
        initDeepFilter()
        initSoundTouch()
    }

    @Synchronized
    fun release() {
        if (debugLog) {
            Log.d(TAG, "release")
        }
        releaseAllContexts()
    }

    private fun initRnnoise() {
        if (rnnoiseContext != 0L) return
        rnnoiseContext = rnnoiseCreate()
        if (debugLog) {
            Log.d(TAG, "RNNoise initialized, context=$rnnoiseContext")
        }
    }

    private fun initDeepFilter() {
        if (dfContext != 0L) return
        val cfg = currentDfConfig
        dfContext = dfCreateFromBytes(
                modelBytes,
                cfg.attenLimDb,
                cfg.minDbThresh,
                cfg.maxDbErbThresh,
                cfg.maxDbDfThresh
        )
        if (dfContext != 0L) {
            dfFrameLength = dfGetFrameLength(dfContext)
            dfOutputBuffer = ByteArray(dfFrameLength * Float.SIZE_BYTES)
            dfSetAttenLim(dfContext, cfg.attenLimDb)
            dfSetPostFilterBeta(dfContext, cfg.postFilterBeta)
        }
        if (debugLog) {
            Log.d(TAG, "DeepFilterNet initialized, context=$dfContext, frameLength=$dfFrameLength")
        }
    }

    private fun initSoundTouch() {
        if (stContext != 0L) return
        stContext = stCreate()
        if (stContext != 0L) {
            stSetPitchSemiTones(stContext, currentStConfig.pitchSemiTones)
        }
        if (debugLog) {
            Log.d(TAG, "SoundTouch initialized, context=$stContext")
        }
    }

    private fun releaseAllContexts() {
        if (rnnoiseContext != 0L) {
            rnnoiseDestroy(rnnoiseContext)
            rnnoiseContext = 0
        }
        if (dfContext != 0L) {
            dfDestroy(dfContext)
            dfContext = 0
            dfFrameLength = 0
            dfOutputBuffer = null
        }
        if (stContext != 0L) {
            stDestroy(stContext)
            stContext = 0
        }
    }

    /* ── RNNoise native methods ─────────────────────────────────────── */
    private external fun rnnoiseCreate(): Long
    private external fun rnnoiseDestroy(st: Long)
    private external fun rnnoiseProcessFrame(st: Long, pcm: ByteArray): Float

    /* ── DeepFilterNet native methods ───────────────────────────────── */
    private external fun dfCreateFromBytes(
            modelBytes: ByteArray,
            attenLimDb: Float,
            minDbThresh: Float,
            maxDbErbThresh: Float,
            maxDbDfThresh: Float
    ): Long

    private external fun dfDestroy(st: Long)
    private external fun dfGetFrameLength(st: Long): Int
    private external fun dfProcessFrame(st: Long, input: ByteArray, output: ByteArray): Float
    private external fun dfSetAttenLim(st: Long, limDb: Float)
    private external fun dfSetPostFilterBeta(st: Long, beta: Float)

    /* ── SoundTouch native methods ──────────────────────────────────── */
    private external fun stCreate(): Long
    private external fun stDestroy(st: Long)
    private external fun stSetPitchSemiTones(st: Long, semitones: Float)
    private external fun stProcessFrame(st: Long, pcm: ByteArray): Boolean
}
